package edu.univ.erp.test;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.AdminService;
import edu.univ.erp.service.StudentService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class StudentServiceTest {

    private StudentService studentService;
    private AdminService adminService;

    @BeforeEach
    void setUp() {
        // Initialize the services
        studentService = new StudentService();
        adminService = new AdminService();

        // SIMULATE A LOGIN (Crucial for UserSession)
        // We simulate a valid Student (ID 1, Role "Student")
        UserSession.getInstance().setSession(1, "stu1", "Student");

        // Ensure Maintenance Mode is OFF before every test
        adminService.setMaintenanceMode(false);
    }

    @AfterEach
    void tearDown() {
        // Clear the session after every test to avoid interference
        UserSession.getInstance().clearSession();
        // Reset maintenance mode
        adminService.setMaintenanceMode(false);
    }

    // --- 1. LOGIC TEST: Capacity Check ---

    @Test
    @DisplayName("Logic: checkAvailability returns true if capacity > 0")
    void testCheckAvailability_Success() {
        // Setup: Create a section with 5 seats
        // Constructor params: (id, courseId, instructorId, day, time, room, CAPACITY, semester, year)
        Section openSection = new Section(101, 1, 1, "Mon", "10:00", "R1", 5, "Fall", 2025);

        boolean result = studentService.checkAvailability(openSection);

        assertTrue(result, "Should be available when capacity is 5");
    }

    @Test
    @DisplayName("Logic: checkAvailability returns false if capacity is 0")
    void testCheckAvailability_Full() {
        // Setup: Create a section with 0 seats
        Section fullSection = new Section(102, 1, 1, "Mon", "10:00", "R1", 0, "Fall", 2025);

        boolean result = studentService.checkAvailability(fullSection);

        assertFalse(result, "Should NOT be available when capacity is 0");
    }

    // --- 2. SECURITY TEST: Role Enforcement ---

    @Test
    @DisplayName("Security: Non-Students cannot register")
    void testRegister_WrongRole() {
        // 1. Simulate an Instructor Logged in
        UserSession.getInstance().setSession(2, "inst1", "Instructor");

        // 2. Try to register
        String result = studentService.registerForSection(101);

        // 3. Verify rejection message
        assertEquals("FAILURE: Only students can register.", result);
    }

    @Test
    @DisplayName("Security: Non-Students cannot drop sections")
    void testDrop_WrongRole() {
        // 1. Simulate an Admin Logged in
        UserSession.getInstance().setSession(99, "admin1", "Admin");

        // 2. Try to drop
        String result = studentService.dropSection(101);

        // 3. Verify rejection message
        assertEquals("FAILURE: Only students can drop sections.", result);
    }

    // --- 3. MAINTENANCE MODE TEST ---

    @Test
    @DisplayName("Maintenance: Registration blocked when Maintenance Mode is ON")
    void testRegister_MaintenanceOn() {
        // 1. Turn Maintenance ON (using AdminService)
        adminService.setMaintenanceMode(true);

        // 2. Try to register as a Student
        String result = studentService.registerForSection(101);

        // 3. Verify blocked message
        assertTrue(result.contains("Maintenance Mode is ON"), "Should block registration during maintenance");
    }

    @Test
    @DisplayName("Maintenance: Dropping blocked when Maintenance Mode is ON")
    void testDrop_MaintenanceOn() {
        // 1. Turn Maintenance ON
        adminService.setMaintenanceMode(true);

        // 2. Try to drop
        String result = studentService.dropSection(101);

        // 3. Verify blocked message
        assertTrue(result.contains("Maintenance Mode is ON"), "Should block dropping during maintenance");
    }

    // --- 4. DATE LOGIC TEST ---

    @Test
    @DisplayName("Date: Deadline string is formatted correctly")
    void testDeadlineString() {
        // Your code hardcodes "December 31, 2025"
        String deadline = studentService.getDeadlineString();
        assertNotNull(deadline);
        assertEquals("December 31, 2025", deadline);
    }

    // Note: We cannot easily test "Past Deadline" unless we change the system clock
    // or the code date, so we assume the Happy Path (before 2025) works.
}