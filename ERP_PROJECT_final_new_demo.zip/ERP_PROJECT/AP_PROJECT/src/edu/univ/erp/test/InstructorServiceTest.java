package edu.univ.erp.test;

import edu.univ.erp.service.InstructorService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InstructorServiceTest {

    @Test
    @DisplayName("Test Grading Calculation: 20% Quiz, 30% Mid, 50% End")
    void testComputeFinalGrade() {
        InstructorService service = new InstructorService();

        // Scenario:
        // Quiz: 80/100 (Weight 20%) -> 16.0
        // Midterm: 90/100 (Weight 30%) -> 27.0
        // EndSem: 70/100 (Weight 50%) -> 35.0
        // Expected Total: 16 + 27 + 35 = 78.0

        double result = service.computeFinalGrade(80.0, 90.0, 70.0);

        assertEquals(78.0, result, 0.01, "Final grade calculation is incorrect");
    }

    @Test
    @DisplayName("Test Invalid Grades (Negative inputs)")
    void testNegativeGrades() {
        InstructorService service = new InstructorService();

        // Expect the service to throw an exception if scores are invalid
        // (You must ensure your service throws IllegalArgumentException for this to pass)
        assertThrows(IllegalArgumentException.class, () -> {
            service.computeFinalGrade(-10.0, 50.0, 50.0);
        });
    }
}