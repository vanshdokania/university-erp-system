package edu.univ.erp.test;

import edu.univ.erp.service.AdminService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AdminServiceTest {

    @Test
    @DisplayName("Maintenance Mode should default to OFF")
    void testDefaultMaintenanceStatus() {
        AdminService service = new AdminService();
        assertFalse(service.isMaintenanceMode(), "Maintenance should be OFF by default");
    }

    @Test
    @DisplayName("Toggle Maintenance Mode ON/OFF")
    void testToggleMaintenance() {
        AdminService service = new AdminService();

        // Turn ON
        service.setMaintenanceMode(true);
        assertTrue(service.isMaintenanceMode(), "Maintenance should be ON after setting true");

        // Turn OFF
        service.setMaintenanceMode(false);
        assertFalse(service.isMaintenanceMode(), "Maintenance should be OFF after setting false");
    }
}