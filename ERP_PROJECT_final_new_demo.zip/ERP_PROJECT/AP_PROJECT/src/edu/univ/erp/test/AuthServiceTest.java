package edu.univ.erp.test;

import edu.univ.erp.auth.AuthService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AuthServiceTest {

    @Test
    @DisplayName("Should verify password correctly (Mock Logic)")
    void testPasswordVerification() {
        AuthService auth = new AuthService();

        // This relies on the BCrypt library you added to /lib
        String rawPassword = "mySecretPassword";

        // 1. Hash the password (simulating signup)
        String storedHash = auth.hashPassword(rawPassword);

        // 2. Verify the correct password works
        assertTrue(auth.checkPassword(rawPassword, storedHash), "Correct password should match hash");

        // 3. Verify wrong password fails
        assertFalse(auth.checkPassword("wrong123", storedHash), "Wrong password should fail");
    }
}