// File: edu.univ.erp.DatabaseCheck.java

package edu.univ.erp;

import edu.univ.erp.data.DBConnection;
import java.sql.*;

public class DatabaseCheck {
    public static void main(String[] args) {
        System.out.println("--- DATABASE VISIBILITY TEST ---");

        // 1. Test Connection
        try (Connection conn = DBConnection.getERPDBConnection()) {
            System.out.println("1. Connection Successful to: " + conn.getMetaData().getURL());

            // 2. Dump Enrollments Table
            System.out.println("\n2. Checking 'enrollments' table content:");
            String sql = "SELECT * FROM enrollments";

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {

                boolean hasData = false;
                System.out.printf("%-10s %-10s %-10s %-15s\n", "Enroll_ID", "Student_ID", "Section_ID", "Status");
                System.out.println("-------------------------------------------------------");

                while (rs.next()) {
                    hasData = true;
                    System.out.printf("%-10d %-10d %-10d %-15s\n",
                            rs.getInt("enrollment_id"),
                            rs.getInt("student_id"),
                            rs.getInt("section_id"),
                            rs.getString("status"));
                }

                if (!hasData) {
                    System.err.println("   [WARNING] Java sees 0 rows in 'enrollments'.");
                    System.err.println("   -> Did you click 'Commit' in MySQL Workbench?");
                } else {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("   [SUCCESS] Java can read the data above.");
                }
            }
        } catch (SQLException e) {
            System.err.println("   [CRITICAL ERROR] Connection failed: " + e.getMessage());
        }
    }
}