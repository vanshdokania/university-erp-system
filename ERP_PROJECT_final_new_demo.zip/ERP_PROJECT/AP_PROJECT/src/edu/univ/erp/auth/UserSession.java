package edu.univ.erp.auth;

import edu.univ.erp.domain.User;

public class UserSession {

    private static UserSession instance;

    private User currentUser;

    private UserSession() {}

    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setSession(int userId, String username, String role) {
        this.currentUser = new User(userId, username, role);
    }

    public void clearSession() {
        this.currentUser = null;
    }

    public int getProfileId() {
        return (currentUser != null) ? currentUser.getUserId() : 0;
    }

    public String getRole() {
        return (currentUser != null) ? currentUser.getRole() : null;
    }

    public String getUsername() {
        return (currentUser != null) ? currentUser.getUsername() : null;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }
}