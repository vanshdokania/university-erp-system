// File: edu.univ.erp.auth.AuthService.java

package edu.univ.erp.auth;

import edu.univ.erp.data.DBConnection;
import org.mindrot.jbcrypt.BCrypt;
import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

public class AuthService {


    public String authenticate(String username, String password) {
        try (Connection conn = DBConnection.getAuthDBConnection()) {

            String sql = "SELECT role, password_hash, failed_attempts, lock_time FROM users_auth WHERE username = ?";

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                try (ResultSet rs = stmt.executeQuery()) {

                    if (!rs.next()) {
                        return "ERR_INVALID"; // User not found
                    }

                    String role = rs.getString("role");
                    String storedHash = rs.getString("password_hash");
                    int failedAttempts = rs.getInt("failed_attempts");
                    Timestamp lockTime = rs.getTimestamp("lock_time");


                    if (lockTime != null) {
                        if (lockTime.after(new Timestamp(System.currentTimeMillis()))) {
                            return "ERR_LOCKED"; // Account is currently locked
                        }
                    }


                    if (BCrypt.checkpw(password, storedHash)) {
                        // SUCCESS: Reset counter and lock
                        resetLock(conn, username);
                        return role;
                    } else {

                        handleFailedLogin(conn, username, failedAttempts);
                        return "ERR_INVALID";
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error during authentication: " + e.getMessage());
            return "ERR_DB";
        }
    }


    private void resetLock(Connection conn, String username) throws SQLException {
        String sql = "UPDATE users_auth SET failed_attempts = 0, lock_time = NULL WHERE username = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        }
    }

    private void handleFailedLogin(Connection conn, String username, int currentAttempts) throws SQLException {
        int newAttempts = currentAttempts + 1;
        String sql;

        if (newAttempts >= 5) {
            sql = "UPDATE users_auth SET failed_attempts = ?, lock_time = DATE_ADD(NOW(), INTERVAL 30 SECOND) WHERE username = ?";
        } else {

            sql = "UPDATE users_auth SET failed_attempts = ?, lock_time = NULL WHERE username = ?";
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, newAttempts);
            stmt.setString(2, username);
            stmt.executeUpdate();
        }
    }

    public int createBaseUser(String username, String password, String role) {
        String passwordHash = BCrypt.hashpw(password, BCrypt.gensalt());
        final String SQL = "INSERT INTO users_auth (username, role, password_hash) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getAuthDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, username);
            stmt.setString(2, role);
            stmt.setString(3, passwordHash);

            if (stmt.executeUpdate() == 0) return -1;

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) return generatedKeys.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error creating base user: " + e.getMessage());
        }
        return -1;
    }

    public boolean updatePassword(String username, String newPassword) {
        String newHash = BCrypt.hashpw(newPassword, BCrypt.gensalt());
        final String SQL = "UPDATE users_auth SET password_hash = ? WHERE username = ?";

        try (Connection conn = DBConnection.getAuthDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setString(1, newHash);
            stmt.setString(2, username);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating password: " + e.getMessage());
            return false;
        }
    }

    public String hashPassword(String plainText) {
        return BCrypt.hashpw(plainText, BCrypt.gensalt());
    }

    public boolean checkPassword(String plainText, String hashed) {
        return BCrypt.checkpw(plainText, hashed);
    }
}