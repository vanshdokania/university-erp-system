package edu.univ.erp.auth;

// File: edu.univ.erp.auth.HashGenerator.java

import org.mindrot.jbcrypt.BCrypt;


public class HashGenerator {


    public static String hashPassword(String password) {

        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    public static void main(String[] args) {
        System.out.println("--- COPY THESE HASHES FOR DATABASE SEEDING ---");

        // Define simple test passwords for the four required initial users
        System.out.println("admin1 Hash: " + hashPassword("MyAdmin1Pass"));
        System.out.println("inst1 Hash:  " + hashPassword("MyInst1Pass"));
        System.out.println("stu1 Hash:   " + hashPassword("MyStu1Pass"));
        System.out.println("stu2 Hash:   " + hashPassword("MyStu2Pass"));

        System.out.println("----------------------------------------------");
    }
}