package edu.univ.erp.ui;

import edu.univ.erp.service.AdminService;

import javax.swing.*;
import java.awt.*;

public class ManageCoursesDialog extends JDialog {

    private AdminService adminService;
    private JTextField codeField;
    private JTextField titleField;
    private JTextField creditsField;

    public ManageCoursesDialog(JFrame parent) {
        super(parent, "Admin: Manage Courses", true);
        this.adminService = new AdminService();

        setSize(400, 250);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        ThemeManager.applyTheme(inputPanel);
        inputPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(ThemeManager.getBorderColor()),
            "New Course Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 13)
        ));
        ((javax.swing.border.TitledBorder) inputPanel.getBorder()).setTitleColor(ThemeManager.getTextColor());

        codeField = new JTextField(10);
        titleField = new JTextField(15);
        creditsField = new JTextField(5);

        ThemeManager.applyTheme(codeField);
        ThemeManager.applyTheme(titleField);
        ThemeManager.applyTheme(creditsField);

        JLabel codeLabel = new JLabel("Course Code (e.g., CS101):");
        JLabel titleLabel = new JLabel("Course Title:");
        JLabel creditsLabel = new JLabel("Credits:");
        ThemeManager.applyTheme(codeLabel);
        ThemeManager.applyTheme(titleLabel);
        ThemeManager.applyTheme(creditsLabel);

        inputPanel.add(codeLabel);
        inputPanel.add(codeField);
        inputPanel.add(titleLabel);
        inputPanel.add(titleField);
        inputPanel.add(creditsLabel);
        inputPanel.add(creditsField);

        add(inputPanel, BorderLayout.CENTER);

        // --- Action Button ---
        JButton createButton = new JButton("Create Course");
        createButton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        ThemeManager.applyTheme(createButton);
        createButton.addActionListener(e -> handleCreateCourse());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        ThemeManager.applyTheme(buttonPanel);
        buttonPanel.add(createButton);
        add(buttonPanel, BorderLayout.SOUTH);

        getContentPane().setBackground(ThemeManager.getBackground());

        setVisible(true);
    }

    private void handleCreateCourse() {
        String code = codeField.getText().trim();
        String title = titleField.getText().trim();
        String creditsStr = creditsField.getText().trim();

        if (code.isEmpty() || title.isEmpty() || creditsStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double credits = Double.parseDouble(creditsStr);

            String result = adminService.createNewCourse(code, title, credits);

            if (result.startsWith("SUCCESS")) {
                JOptionPane.showMessageDialog(this, result, "Success", JOptionPane.INFORMATION_MESSAGE);
                codeField.setText("");
                titleField.setText("");
                creditsField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, result, "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Credits must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}