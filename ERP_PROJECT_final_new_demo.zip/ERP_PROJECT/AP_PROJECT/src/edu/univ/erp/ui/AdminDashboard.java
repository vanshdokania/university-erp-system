// File: edu.univ.erp.ui.AdminDashboard.java

package edu.univ.erp.ui;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.service.AdminService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminDashboard extends JFrame {

    private AdminService adminService;

    private JCheckBox maintenanceToggle;
    private JLabel bannerLabel;
    private JPanel navPanel;
    private JLabel welcomeLabel;

    private final Color PRIMARY_COLOR = new Color(65, 105, 225); // Royal Blue
    private final Color BACKGROUND_COLOR = Color.WHITE;
    private final Color TEXT_COLOR = new Color(50, 50, 50);
    private final Color WARNING_COLOR = new Color(231, 76, 60); // Red for alerts

    public AdminDashboard(String username) {
        this.adminService = new AdminService();

        setTitle("ADMINISTRATOR Dashboard - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(BACKGROUND_COLOR);

        // --- 1. Top Panel ---
        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.setBackground(BACKGROUND_COLOR);

        welcomeLabel = new JLabel("System Administrator - " + username, SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setForeground(TEXT_COLOR);
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 0));
        topContainer.add(welcomeLabel, BorderLayout.CENTER);

        JPanel settingsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        settingsPanel.setBackground(BACKGROUND_COLOR);
        settingsPanel.setBorder(BorderFactory.createEmptyBorder(25, 0, 0, 20));

        maintenanceToggle = new JCheckBox("Maintenance Mode");
        maintenanceToggle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        maintenanceToggle.setForeground(WARNING_COLOR);
        maintenanceToggle.setBackground(BACKGROUND_COLOR);
        maintenanceToggle.setCursor(new Cursor(Cursor.HAND_CURSOR));
        maintenanceToggle.setFocusPainted(false);

        settingsPanel.add(maintenanceToggle);
        topContainer.add(settingsPanel, BorderLayout.EAST);

        bannerLabel = new JLabel("", SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {

                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        bannerLabel.setOpaque(false); // False because we paint manually
        bannerLabel.setBackground(WARNING_COLOR);
        bannerLabel.setForeground(Color.WHITE);
        bannerLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        bannerLabel.setPreferredSize(new Dimension(10, 35));
        bannerLabel.setVisible(false);

        JPanel northPanel = new JPanel(new BorderLayout());
        northPanel.setBackground(BACKGROUND_COLOR);
        northPanel.add(topContainer, BorderLayout.CENTER);


        JPanel bannerWrapper = new JPanel(new BorderLayout());
        bannerWrapper.setBackground(BACKGROUND_COLOR);
        bannerWrapper.setBorder(new EmptyBorder(5, 10, 5, 10));
        bannerWrapper.add(bannerLabel, BorderLayout.CENTER);

        northPanel.add(bannerWrapper, BorderLayout.SOUTH);
        add(northPanel, BorderLayout.NORTH);

        // --- 2. Sidebar ---
        initSidebar();


        JLabel mainContent = new JLabel("Use the menu to perform system-wide management tasks.", SwingConstants.CENTER);
        mainContent.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        mainContent.setForeground(Color.GRAY);
        add(mainContent, BorderLayout.CENTER);

        initializeMaintenanceMode();
        addToggleListener();

        setVisible(true);
    }

    private void initSidebar() {
        navPanel = new JPanel();
        navPanel.setLayout(new GridLayout(9, 1, 10, 15)); // 8 Buttons + spacing
        navPanel.setBackground(BACKGROUND_COLOR);
        navPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Admin Menu"),
                new EmptyBorder(10, 10, 10, 10)
        ));


        JButton btnUsers = createStyledButton("Manage Users");
        JButton btnCourses = createStyledButton("Create Courses");
        JButton btnSections = createStyledButton("Create Sections");
        JButton btnAssign = createStyledButton("Assign Instructors");
        JButton btnViewEnroll = createStyledButton("View Enrollments");
        JButton btnLogs = createStyledButton("System Logs");
        JButton btnPassword = createStyledButton("Change Password");
        JButton btnLogout = createStyledButton("Logout");


        btnLogout.setBackground(new Color(231, 76, 60));
        btnLogout.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) { btnLogout.setBackground(new Color(231, 76, 60).darker()); }
            public void mouseExited(MouseEvent evt) { btnLogout.setBackground(new Color(231, 76, 60)); }
        });


        btnUsers.addActionListener(e -> new ManageUsersDialog(this).setVisible(true));
        btnCourses.addActionListener(e -> new ManageCoursesDialog(this).setVisible(true));
        btnSections.addActionListener(e -> new ManageSectionsDialog(this).setVisible(true));
        btnAssign.addActionListener(e -> new AssignInstructorDialog(this).setVisible(true));
        btnViewEnroll.addActionListener(e -> new ViewEnrollmentsDialog(this).setVisible(true));
        btnLogs.addActionListener(e -> new SystemSettingsDialog(this).setVisible(true));
        btnPassword.addActionListener(e -> new ChangePasswordDialog(this).setVisible(true));

        btnLogout.addActionListener(e -> {
            UserSession.getInstance().clearSession();
            JOptionPane.showMessageDialog(this, "Logged out successfully.", "Logout", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
            new LoginWindow();
        });


        navPanel.add(btnUsers);
        navPanel.add(btnCourses);
        navPanel.add(btnSections);
        navPanel.add(btnAssign);
        navPanel.add(btnViewEnroll);
        navPanel.add(btnLogs);
        navPanel.add(btnPassword);
        navPanel.add(Box.createGlue()); // Spacer
        navPanel.add(btnLogout);

        JPanel westContainer = new JPanel(new BorderLayout());
        westContainer.setBackground(BACKGROUND_COLOR);
        westContainer.add(navPanel, BorderLayout.NORTH);
        westContainer.setPreferredSize(new Dimension(240, 0));

        add(westContainer, BorderLayout.WEST);
    }

    private void initializeMaintenanceMode() {
        boolean isEnabled = adminService.isMaintenanceModeEnabled();
        maintenanceToggle.setSelected(isEnabled);
        updateMaintenanceBanner(isEnabled);
    }

    private void updateMaintenanceBanner(boolean isEnabled) {
        if (isEnabled) {
            bannerLabel.setText("!!! SYSTEM IS IN MAINTENANCE MODE: ALL WRITES ARE BLOCKED !!!");
            bannerLabel.setVisible(true);
        } else {
            bannerLabel.setText("");
            bannerLabel.setVisible(false);
        }
        this.revalidate();
        this.repaint();
    }

    private void addToggleListener() {
        maintenanceToggle.addActionListener(e -> {
            boolean newState = maintenanceToggle.isSelected();
            String result = adminService.toggleMaintenanceMode(newState);

            if (result.startsWith("SUCCESS")) {
                updateMaintenanceBanner(newState);
                JOptionPane.showMessageDialog(this, result, "System Update", JOptionPane.INFORMATION_MESSAGE);
            } else {
                maintenanceToggle.setSelected(!newState); // Revert if failed
                JOptionPane.showMessageDialog(this, result, "System Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.dispose();
                super.paintComponent(g);
            }
        };

        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);

        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);


        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {

                if (!btn.getText().equals("Logout")) { // Keep red button logic separate
                    btn.setBackground(PRIMARY_COLOR.brighter());
                }
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (!btn.getText().equals("Logout")) {
                    btn.setBackground(PRIMARY_COLOR);
                }
            }
        });

        return btn;
    }
}