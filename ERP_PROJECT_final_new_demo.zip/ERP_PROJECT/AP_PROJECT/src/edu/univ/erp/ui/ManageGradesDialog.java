// File: edu.univ.erp.ui.ManageGradesDialog.java

package edu.univ.erp.ui;

import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.service.InstructorService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ManageGradesDialog extends JDialog {

    private InstructorService instructorService;
    private int sectionId;
    private JTable rosterTable;
    private DefaultTableModel tableModel;

    public ManageGradesDialog(JFrame parent, int sectionId, String courseInfo) {
        super(parent, "Manage Grades: " + courseInfo, true);
        this.instructorService = new InstructorService();
        this.sectionId = sectionId;

        setSize(700, 500);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JLabel titleLabel = new JLabel("Class Roster for Section ID: " + sectionId, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        add(titleLabel, BorderLayout.NORTH);

        String[] columnNames = {"Enrollment ID", "Roll No", "Student Name", "Program", "Current Grade"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };
        rosterTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(rosterTable);
        add(scrollPane, BorderLayout.CENTER);

        JButton submitButton = new JButton("Submit Grade Changes");
        submitButton.addActionListener(e -> handleSubmitGrades());
        add(submitButton, BorderLayout.SOUTH);

        loadRoster();
        setVisible(true);
    }


    private void loadRoster() {
        tableModel.setRowCount(0);

        List<Enrollment> roster = instructorService.getEnrolledStudents(sectionId);

        for (Enrollment enrollment : roster) {
            Object[] row = new Object[]{
                    enrollment.getEnrollmentId(),
                    enrollment.student.getRollNo(),
                    enrollment.student.getUsername(),
                    enrollment.student.getProgram(),
                    enrollment.getGrade() != null ? enrollment.getGrade() : "" // Display existing grade or blank
            };
            tableModel.addRow(row);
        }
    }


    private void handleSubmitGrades() {
        int rowsUpdated = 0;
        int rowCount = tableModel.getRowCount();

        for (int i = 0; i < rowCount; i++) {
            try {
                int enrollmentId = (int) tableModel.getValueAt(i, 0);
                String newGrade = tableModel.getValueAt(i, 4).toString().trim(); // Grade is in column index 4

                if (!newGrade.isEmpty()) {
                    String result = instructorService.submitGrade(enrollmentId, newGrade);

                    if (result.startsWith("SUCCESS")) {
                        rowsUpdated++;
                    } else if (!result.contains("Invalid grade format")) {

                        System.err.println("Failed to update grade for Enrollment ID " + enrollmentId + ": " + result);
                    }
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error processing grade submission on row " + (i+1) + ".", "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }

        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, rowsUpdated + " grade(s) submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

            loadRoster();
        } else {
            JOptionPane.showMessageDialog(this, "No valid grade changes were submitted or found.", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }
}