// File: edu.univ.erp.ui.ComputeGradesDialog.java

package edu.univ.erp.ui;

import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.service.InstructorService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ComputeGradesDialog extends JDialog {

    private InstructorService instructorService;
    private JComboBox<String> studentCombo;
    private JTextField quizField, midtermField, finalField;
    private JLabel resultLabel;
    private List<Enrollment> roster;

    public ComputeGradesDialog(JFrame parent, int sectionId) {
        super(parent, "Compute Final Grades", true);
        this.instructorService = new InstructorService();

        setSize(450, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        // 1. Student Selection
        roster = instructorService.getEnrolledStudents(sectionId);

        // NEW: Check if roster is empty and warn user
        if (roster.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No students found for Section ID: " + sectionId + ".\nEnsure students are registered in this section.",
                    "Empty Roster", JOptionPane.WARNING_MESSAGE);
        }

        studentCombo = new JComboBox<>();
        for (Enrollment e : roster) {
            studentCombo.addItem(e.student.getRollNo() + " - " + e.student.getUsername());
        }

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Grade Calculator (20/30/50)"));

        formPanel.add(new JLabel("Select Student:"));
        formPanel.add(studentCombo);

        quizField = new JTextField("0");
        midtermField = new JTextField("0");
        finalField = new JTextField("0");

        formPanel.add(new JLabel("Quiz Score (20%):"));
        formPanel.add(quizField);
        formPanel.add(new JLabel("Midterm Score (30%):"));
        formPanel.add(midtermField);
        formPanel.add(new JLabel("Final Exam (50%):"));
        formPanel.add(finalField);

        resultLabel = new JLabel("Calculated: -");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(new JLabel("Final Grade:"));
        formPanel.add(resultLabel);

        add(formPanel, BorderLayout.CENTER);

        // 2. Actions
        JPanel btnPanel = new JPanel();
        JButton calcButton = new JButton("Calculate");
        JButton saveButton = new JButton("Save to DB");

        calcButton.addActionListener(e -> calculate());
        saveButton.addActionListener(e -> saveGrade());

        btnPanel.add(calcButton);
        btnPanel.add(saveButton);
        add(btnPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private String currentCalculatedGrade = null;

    private void calculate() {
        try {
            double q = Double.parseDouble(quizField.getText());
            double m = Double.parseDouble(midtermField.getText());
            double f = Double.parseDouble(finalField.getText());

            double total = (q * 0.2) + (m * 0.3) + (f * 0.5);

            if (total >= 90) currentCalculatedGrade = "A";
            else if (total >= 80) currentCalculatedGrade = "B";
            else if (total >= 70) currentCalculatedGrade = "C";
            else if (total >= 60) currentCalculatedGrade = "D";
            else currentCalculatedGrade = "F";

            resultLabel.setText(String.format("%.2f (%s)", total, currentCalculatedGrade));
            resultLabel.setForeground(new Color(0, 100, 0));

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveGrade() {
        if (currentCalculatedGrade == null) {
            JOptionPane.showMessageDialog(this, "Please click Calculate first.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int selectedIndex = studentCombo.getSelectedIndex();
        if (selectedIndex != -1) {
            Enrollment e = roster.get(selectedIndex);
            String result = instructorService.submitGrade(e.getEnrollmentId(), currentCalculatedGrade);
            JOptionPane.showMessageDialog(this, result);
        }
    }
}