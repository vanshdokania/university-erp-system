// File: edu.univ.erp.ui.RegisterDropDialog.java

package edu.univ.erp.ui;

import edu.univ.erp.data.SectionDAO;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.StudentService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class RegisterDropDialog extends JDialog {

    private JTable catalogTable;
    private DefaultTableModel tableModel;
    private StudentService studentService;
    private SectionDAO sectionDAO;

    // Theme Colors
    private final Color PRIMARY_COLOR = new Color(65, 105, 225); // Royal Blue
    private final Color BACKGROUND_COLOR = new Color(245, 245, 250); // Light Grey
    private final Color DANGER_COLOR = new Color(231, 76, 60); // Red

    public RegisterDropDialog(JFrame parent) {
        super(parent, "Course Registration", true);
        setSize(900, 550);
        setLocationRelativeTo(parent);

        this.studentService = new StudentService();
        this.sectionDAO = new SectionDAO();

        setLayout(new BorderLayout(0, 0));


        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));

        JLabel titleLabel = new JLabel("Course Catalog & Registration");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(new Color(50, 50, 50));

        JLabel deadlineLabel = new JLabel("Deadline: " + studentService.getDeadlineString());
        deadlineLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        deadlineLabel.setForeground(DANGER_COLOR);

        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(deadlineLabel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);


        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBackground(BACKGROUND_COLOR);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 0, 15));


        String[] columnNames = {"Section ID", "Code", "Title", "Credits", "Schedule", "Capacity", "Sem/Year"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        catalogTable = new JTable(tableModel);
        styleTable(catalogTable);

        JScrollPane scrollPane = new JScrollPane(catalogTable);
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        contentPanel.add(scrollPane, BorderLayout.CENTER);
        add(contentPanel, BorderLayout.CENTER);

        // --- 3. Footer/Action Panel ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonPanel.setBackground(BACKGROUND_COLOR);

        JButton registerButton = createStyledButton("Register Selected", PRIMARY_COLOR);
        JButton dropButton = createStyledButton("Drop Selected", DANGER_COLOR);
        JButton closeButton = createStyledButton("Close", new Color(100, 100, 100));

        // Actions
        registerButton.addActionListener(e -> handleRegistration());
        dropButton.addActionListener(e -> handleDrop());
        closeButton.addActionListener(e -> dispose());

        buttonPanel.add(registerButton);
        buttonPanel.add(dropButton);
        buttonPanel.add(closeButton);

        add(buttonPanel, BorderLayout.SOUTH);

        loadCourseCatalog();
    }

    private void loadCourseCatalog() {
        tableModel.setRowCount(0);
        List<Section> sections = sectionDAO.getAllSections();
        for (Section s : sections) {
            String schedule = s.getDay() + " " + s.getTime() + " (" + s.getRoom() + ")";
            Object[] row = {
                    s.getSectionId(),
                    s.course != null ? s.course.getCode() : "N/A",
                    s.course != null ? s.course.getTitle() : "N/A",
                    s.course != null ? s.course.getCredits() : 0.0,
                    schedule,
                    s.getCapacity(),
                    s.getSemester() + " " + s.getYear()
            };
            tableModel.addRow(row);
        }
    }

    private void handleRegistration() {
        int selectedRow = catalogTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a course to register.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int sectionId = (int) catalogTable.getValueAt(selectedRow, 0);
        String courseCode = (String) catalogTable.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Register for " + courseCode + " (Section ID: " + sectionId + ")?",
                "Confirm Registration", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            String result = studentService.registerForSection(sectionId);
            showResultDialog(result);
        }
    }

    private void handleDrop() {
        int selectedRow = catalogTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a course to drop.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int sectionId = (int) catalogTable.getValueAt(selectedRow, 0);
        String courseCode = (String) catalogTable.getValueAt(selectedRow, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to DROP " + courseCode + "?\nThis cannot be undone.",
                "Confirm Drop", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            String result = studentService.dropSection(sectionId);
            showResultDialog(result);
        }
    }

    private void showResultDialog(String result) {
        if (result.startsWith("SUCCESS")) {
            JOptionPane.showMessageDialog(this, result, "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, result, "Action Failed", JOptionPane.ERROR_MESSAGE);
        }
    }



    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(230, 230, 230));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setShowVerticalLines(false);

        JTableHeader header = table.getTableHeader();
        header.setDefaultRenderer((table1, value, isSelected, hasFocus, row, column) -> {
            JLabel label = new JLabel(value.toString());
            label.setOpaque(true);
            label.setBackground(PRIMARY_COLOR);
            label.setForeground(Color.WHITE);
            label.setFont(new Font("Segoe UI", Font.BOLD, 13));
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.WHITE));
            return label;
        });
    }

    private JButton createStyledButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}