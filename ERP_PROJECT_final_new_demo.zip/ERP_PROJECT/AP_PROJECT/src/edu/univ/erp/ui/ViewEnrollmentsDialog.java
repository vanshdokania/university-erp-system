// File: edu.univ.erp.ui.ViewEnrollmentsDialog.java

package edu.univ.erp.ui;

import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.service.AdminService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class ViewEnrollmentsDialog extends JDialog {

    private AdminService adminService;
    private JTable table;
    private DefaultTableModel tableModel;


    private final Color PRIMARY_COLOR = new Color(65, 105, 225);
    private final Color BACKGROUND_COLOR = Color.WHITE;

    public ViewEnrollmentsDialog(JFrame parent) {
        super(parent, "Admin: All System Enrollments", true);
        this.adminService = new AdminService();

        setSize(900, 600);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(BACKGROUND_COLOR);


        JLabel titleLabel = new JLabel("Master Enrollment List", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(50, 50, 50));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(titleLabel, BorderLayout.NORTH);

        String[] columnNames = {"Enrollment ID", "Student Name", "Course Code", "Section ID", "Semester", "Year", "Grade", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(tableModel);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(BACKGROUND_COLOR);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
        add(scrollPane, BorderLayout.CENTER);

        // Refresh Button
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setBackground(BACKGROUND_COLOR);

        JButton refreshButton = createStyledButton("Refresh List");
        refreshButton.addActionListener(e -> loadEnrollments());

        btnPanel.add(refreshButton);
        add(btnPanel, BorderLayout.SOUTH);

        loadEnrollments();
    }

    private void loadEnrollments() {
        tableModel.setRowCount(0);
        List<Enrollment> list = adminService.viewAllEnrollments();

        for (Enrollment e : list) {
            Object[] row = {
                    e.getEnrollmentId(),
                    e.student != null ? e.student.getUsername() : "N/A",
                    e.section != null && e.section.course != null ? e.section.course.getCode() : "N/A",
                    e.getSectionId(),
                    e.section != null ? e.section.getSemester() : "",
                    e.section != null ? e.section.getYear() : "",
                    e.getGrade(),
                    e.getStatus()
            };
            tableModel.addRow(row);
        }
    }

    private void styleTable(JTable table) {
        table.setRowHeight(25);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(230, 230, 230));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setShowVerticalLines(false);

        JTableHeader header = table.getTableHeader();
        header.setDefaultRenderer((table1, value, isSelected, hasFocus, row, column) -> {
            JLabel label = new JLabel(value.toString());
            label.setOpaque(true);
            label.setBackground(PRIMARY_COLOR);
            label.setForeground(Color.WHITE);
            label.setFont(new Font("Segoe UI", Font.BOLD, 12));
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.WHITE));
            return label;
        });
    }

    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}