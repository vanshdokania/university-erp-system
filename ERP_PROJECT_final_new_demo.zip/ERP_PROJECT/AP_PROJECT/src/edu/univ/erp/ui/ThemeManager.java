// File: edu.univ.erp.ui.ThemeManager.java

package edu.univ.erp.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

public class ThemeManager {

    private static boolean isDarkMode = false;


    public static final Color ACCENT_COLOR = new Color(65, 105, 225); // Royal Blue
    private static final Color ACCENT_SECONDARY = new Color(100, 149, 237); // Cornflower Blue


    private static final Color LIGHT_BG = new Color(245, 245, 250);
    private static final Color LIGHT_PANEL = new Color(255, 255, 255);
    private static final Color LIGHT_TEXT = new Color(50, 50, 50);
    private static final Color LIGHT_INPUT = new Color(255, 255, 255);
    private static final Color LIGHT_BORDER = new Color(200, 200, 200);


    private static final Color DARK_BG = new Color(30, 30, 30);
    private static final Color DARK_PANEL = new Color(45, 45, 45);
    private static final Color DARK_TEXT = new Color(230, 230, 230);
    private static final Color DARK_INPUT = new Color(60, 60, 60);
    private static final Color DARK_BORDER = new Color(80, 80, 80);

    public static boolean isDarkMode() { return isDarkMode; }
    public static void setDarkMode(boolean dark) { isDarkMode = dark; }
    public static void toggleTheme() { isDarkMode = !isDarkMode; }


    public static Color getBackground() { return isDarkMode ? DARK_BG : LIGHT_BG; }
    public static Color getPanelBackground() { return isDarkMode ? DARK_PANEL : LIGHT_PANEL; }
    public static Color getTextColor() { return isDarkMode ? DARK_TEXT : LIGHT_TEXT; }
    public static Color getInputBackground() { return isDarkMode ? DARK_INPUT : LIGHT_INPUT; }
    public static Color getBorderColor() { return isDarkMode ? DARK_BORDER : LIGHT_BORDER; }
    public static Color getButtonBackground() { return ACCENT_COLOR; }
    public static Color getButtonHover() { return ACCENT_COLOR.darker(); }
    public static Color getAccentSecondary() { return ACCENT_SECONDARY; }



    public static JPanel createTransparentPanel(float alpha) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));
                g2d.setColor(getPanelBackground());
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20); // Rounded corners
                g2d.dispose();
                super.paintComponent(g);
            }
        };
    }

    public static void applyTheme(JComponent component) {
        if (component instanceof JLabel) {
            component.setForeground(getTextColor());
        } else if (component instanceof JTextField) {
            component.setBackground(getInputBackground());
            component.setForeground(getTextColor());
            ((JTextField) component).setCaretColor(getTextColor());
            component.setBorder(BorderFactory.createCompoundBorder(
                    new LineBorder(getBorderColor(), 1),
                    new EmptyBorder(5, 10, 5, 10)
            ));
        } else if (component instanceof JPanel) {
            component.setBackground(getPanelBackground());
        }
    }
}