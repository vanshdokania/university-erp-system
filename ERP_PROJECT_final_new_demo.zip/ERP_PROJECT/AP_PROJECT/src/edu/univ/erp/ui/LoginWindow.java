package edu.univ.erp.ui;

import edu.univ.erp.auth.AuthService;
import edu.univ.erp.auth.UserSession;
import edu.univ.erp.data.UserDAO;
import edu.univ.erp.domain.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class LoginWindow extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton themeToggleBtn;
    private JPanel mainPanel;
    private JPanel backgroundPanel;
    private JLabel titleLabel;
    private JLabel userLabel;
    private JLabel passLabel;
    private JLabel timerLabel; // NEW: Label for countdown
    private Image backgroundImage;


    private AuthService authService;
    private UserDAO userDAO;


    private Timer lockoutTimer;
    private int countdownSeconds = 30;

    public LoginWindow() {
        authService = new AuthService();
        userDAO = new UserDAO();


        setTitle("University ERP - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 650); // Increased height slightly for timer
        setLocationRelativeTo(null); // Center on screen
        setResizable(true);

        loadBackgroundImage();
        initUI();
        applyTheme();
        setVisible(true);
    }

    private void loadBackgroundImage() {
        try {
            String[] possiblePaths = {
                    "AP_PROJECT/college photo.jpeg",
                    "college photo.jpeg",
                    "../college photo.jpeg",
                    "src/college photo.jpeg"
            };

            File imageFile = null;
            for (String path : possiblePaths) {
                imageFile = new File(path);
                if (imageFile.exists()) {
                    break;
                }
            }

            if (imageFile != null && imageFile.exists()) {
                backgroundImage = ImageIO.read(imageFile);
            } else {
                backgroundImage = null;
            }
        } catch (IOException e) {
            System.err.println("Could not load background image: " + e.getMessage());
            backgroundImage = null;
        }
    }

    private void initUI() {
        backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    Graphics2D g2d = (Graphics2D) g;
                    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } else {
                    Graphics2D g2d = (Graphics2D) g;
                    GradientPaint gradient = new GradientPaint(
                            0, 0, ThemeManager.getBackground(),
                            getWidth(), getHeight(), ThemeManager.getAccentSecondary()
                    );
                    g2d.setPaint(gradient);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        backgroundPanel.setLayout(new BorderLayout());
        mainPanel = ThemeManager.createTransparentPanel(0.90f);
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(new EmptyBorder(40, 50, 40, 50));

        titleLabel = new JLabel("Welcome Back");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        userLabel = new JLabel("Username");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));

        usernameField = new JTextField(18);
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));

        passwordField = new JPasswordField(18);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        loginButton = new JButton("LOGIN");
        loginButton.setFocusPainted(false);
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        loginButton.setBorder(new EmptyBorder(12, 0, 12, 0));
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        loginButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                if (loginButton.isEnabled())
                    loginButton.setBackground(ThemeManager.getButtonHover());
            }
            public void mouseExited(MouseEvent evt) {
                if (loginButton.isEnabled())
                    loginButton.setBackground(ThemeManager.getButtonBackground());
            }
        });

        timerLabel = new JLabel("");
        timerLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        timerLabel.setForeground(new Color(231, 76, 60)); // Red color
        timerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        timerLabel.setVisible(false);


        themeToggleBtn = new JButton("☾");
        themeToggleBtn.setFocusPainted(false);
        themeToggleBtn.setBorderPainted(false);
        themeToggleBtn.setContentAreaFilled(false);
        themeToggleBtn.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        themeToggleBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        themeToggleBtn.addActionListener(e -> toggleTheme());

        setLayout(new BorderLayout());

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(15, 0, 0, 15));
        topBar.add(themeToggleBtn);

        backgroundPanel.add(topBar, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        gbc.gridy = 0; gbc.insets = new Insets(0, 0, 30, 0);
        mainPanel.add(titleLabel, gbc);

        gbc.gridy = 1; gbc.insets = new Insets(5, 0, 5, 0);
        mainPanel.add(userLabel, gbc);

        gbc.gridy = 2; gbc.insets = new Insets(0, 0, 15, 0);
        gbc.ipady = 12;
        mainPanel.add(usernameField, gbc);

        gbc.gridy = 3; gbc.insets = new Insets(5, 0, 5, 0);
        gbc.ipady = 0;
        mainPanel.add(passLabel, gbc);

        gbc.gridy = 4; gbc.insets = new Insets(0, 0, 25, 0);
        gbc.ipady = 12;
        mainPanel.add(passwordField, gbc);

        gbc.gridy = 5;
        gbc.ipady = 0;
        gbc.insets = new Insets(10, 0, 10, 0);
        mainPanel.add(loginButton, gbc);

        // Add Timer Label at the bottom
        gbc.gridy = 6;
        mainPanel.add(timerLabel, gbc);

        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setOpaque(false);
        centerWrapper.add(mainPanel);
        backgroundPanel.add(centerWrapper, BorderLayout.CENTER);

        add(backgroundPanel, BorderLayout.CENTER);

        loginButton.addActionListener(e -> performLogin());
    }

    private void toggleTheme() {
        ThemeManager.toggleTheme();
        applyTheme();
        repaint();
    }

    private void applyTheme() {
        String toggleText = ThemeManager.isDarkMode() ? "☀" : "☾";

        titleLabel.setForeground(ThemeManager.getTextColor());
        userLabel.setForeground(ThemeManager.getTextColor());
        passLabel.setForeground(ThemeManager.getTextColor());
        themeToggleBtn.setForeground(ThemeManager.getTextColor());
        themeToggleBtn.setText(toggleText);

        ThemeManager.applyTheme(usernameField);
        ThemeManager.applyTheme(passwordField);

        if (loginButton.isEnabled()) {
            loginButton.setBackground(ThemeManager.getButtonBackground());
            loginButton.setForeground(Color.WHITE);
        }

        if (backgroundPanel != null) backgroundPanel.repaint();
        if (mainPanel != null) mainPanel.repaint();
    }

    private void performLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String result = authService.authenticate(username, password);

        if (result == null || result.startsWith("ERR_")) {
            if ("ERR_LOCKED".equals(result)) {

                startLockoutCountdown();
                JOptionPane.showMessageDialog(this,
                        "Account locked due to too many failed attempts.",
                        "Account Locked", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                passwordField.setText("");
            }
            return;
        }

        String userRole = result;
        User baseUser = userDAO.getUserByUsername(username);
        User completeProfile = null;

        if (baseUser != null) {
            if ("Student".equals(userRole)) {
                completeProfile = userDAO.getStudentProfile(baseUser);
            } else if ("Instructor".equals(userRole)) {
                completeProfile = userDAO.getInstructorProfile(baseUser);
            } else if ("Admin".equals(userRole)) {
                completeProfile = userDAO.getAdminProfile(baseUser);
            }
        }

        if (completeProfile != null) {
            UserSession.getInstance().setCurrentUser(completeProfile);
            JOptionPane.showMessageDialog(this, "Login Successful! Opening " + userRole + " Dashboard.");
            dispose();
            openDashboard(userRole);
        } else {
            JOptionPane.showMessageDialog(this, "Profile data missing.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void startLockoutCountdown() {

        usernameField.setEnabled(false);
        passwordField.setEnabled(false);
        loginButton.setEnabled(false);
        loginButton.setBackground(Color.GRAY);

        countdownSeconds = 30;
        timerLabel.setVisible(true);
        timerLabel.setText("Try again in " + countdownSeconds + " seconds");

        lockoutTimer = new Timer(1000, e -> {
            countdownSeconds--;
            if (countdownSeconds > 0) {
                timerLabel.setText("Try again in " + countdownSeconds + " seconds");
            } else {
                ((Timer)e.getSource()).stop();
                resetLoginState();
            }
        });
        lockoutTimer.start();
    }

    private void resetLoginState() {
        usernameField.setEnabled(true);
        passwordField.setEnabled(true);
        passwordField.setText(""); // Clear password

        loginButton.setEnabled(true);
        loginButton.setBackground(ThemeManager.getButtonBackground());

        timerLabel.setVisible(false);
    }

    private void openDashboard(String role) {
        String username = UserSession.getInstance().getUsername();
        switch (role) {
            case "Admin": new AdminDashboard(username).setVisible(true); break;
            case "Instructor": new InstructorDashboard(username).setVisible(true); break;
            case "Student": new StudentDashboard(username).setVisible(true); break;
            default: JOptionPane.showMessageDialog(null, "Unknown role: " + role);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginWindow::new);
    }
}