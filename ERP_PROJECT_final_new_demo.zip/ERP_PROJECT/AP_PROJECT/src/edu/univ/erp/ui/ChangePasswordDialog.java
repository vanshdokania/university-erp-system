package edu.univ.erp.ui;

import edu.univ.erp.auth.AuthService;
import edu.univ.erp.auth.UserSession;

import javax.swing.*;
import java.awt.*;

public class ChangePasswordDialog extends JDialog {

    private JPasswordField currentPassField;
    private JPasswordField newPassField;
    private JPasswordField confirmPassField;
    private AuthService authService;

    public ChangePasswordDialog(JFrame parent) {
        super(parent, "Change Password", true);
        this.authService = new AuthService();

        setSize(400, 250);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));

        currentPassField = new JPasswordField();
        newPassField = new JPasswordField();
        confirmPassField = new JPasswordField();

        inputPanel.add(new JLabel("Current Password:"));
        inputPanel.add(currentPassField);
        inputPanel.add(new JLabel("New Password:"));
        inputPanel.add(newPassField);
        inputPanel.add(new JLabel("Confirm New Password:"));
        inputPanel.add(confirmPassField);

        add(inputPanel, BorderLayout.CENTER);


        JButton changeButton = new JButton("Change Password");
        changeButton.addActionListener(e -> handleChangePassword());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(changeButton);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void handleChangePassword() {
        String currentPass = new String(currentPassField.getPassword());
        String newPass = new String(newPassField.getPassword());
        String confirmPass = new String(confirmPassField.getPassword());
        String username = UserSession.getInstance().getUsername();

        if (currentPass.isEmpty() || newPass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!newPass.equals(confirmPass)) {
            JOptionPane.showMessageDialog(this, "New passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (authService.authenticate(username, currentPass) == null) {
            JOptionPane.showMessageDialog(this, "Incorrect current password.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (authService.updatePassword(username, newPass)) {
            JOptionPane.showMessageDialog(this, "Password changed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Database error occurred.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}