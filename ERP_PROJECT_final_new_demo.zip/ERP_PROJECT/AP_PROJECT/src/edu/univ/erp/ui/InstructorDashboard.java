package edu.univ.erp.ui;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.InstructorService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class InstructorDashboard extends JFrame {

    private InstructorService instructorService;
    private JTable sectionTable;
    private DefaultTableModel tableModel;
    private JPanel navPanel;


    private final Color PRIMARY_COLOR = new Color(65, 105, 225);

    private final Color BACKGROUND_COLOR = new Color(236, 242, 248);
    private final Color WHITE_PANEL_COLOR = Color.WHITE;

    public InstructorDashboard(String username) {
        this.instructorService = new InstructorService();

        setTitle("INSTRUCTOR Dashboard - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);


        setLayout(new BorderLayout(15, 15)); // Increased gap slightly for better spacing
        getContentPane().setBackground(BACKGROUND_COLOR);


        String role = UserSession.getInstance().getRole();
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(WHITE_PANEL_COLOR); // White header
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200))); // Subtle bottom line

        JLabel welcomeLabel = new JLabel("Welcome, " + role + " " + username + "!", SwingConstants.LEFT);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        welcomeLabel.setForeground(new Color(50, 50, 50));
        welcomeLabel.setBorder(new EmptyBorder(15, 20, 15, 20)); // Padding

        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);


        navPanel = new JPanel();
        navPanel.setLayout(new GridLayout(7, 1, 10, 15));
        navPanel.setBackground(WHITE_PANEL_COLOR); // White Sidebar for contrast
        navPanel.setBorder(new EmptyBorder(20, 10, 20, 10));


        navPanel.add(createStyledButton("View My Sections"));
        navPanel.add(createStyledButton("Enter Scores/Grades"));
        navPanel.add(createStyledButton("Compute Final Grades"));
        navPanel.add(createStyledButton("View Simple Statistics"));
        navPanel.add(createStyledButton("Change Password"));
        navPanel.add(createStyledButton("Logout"));


        JPanel westContainer = new JPanel(new BorderLayout());
        westContainer.setBackground(WHITE_PANEL_COLOR);
        westContainer.add(navPanel, BorderLayout.NORTH);
        westContainer.setPreferredSize(new Dimension(240, 0)); // Slightly wider sidebar

        westContainer.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(200, 200, 200)));

        add(westContainer, BorderLayout.WEST);


        String[] columnNames = {"Section ID", "Course Code", "Course Title", "Credits", "Schedule", "Capacity"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        sectionTable = new JTable(tableModel);
        styleTable(sectionTable);

        JScrollPane scrollPane = new JScrollPane(sectionTable);

        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());


        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(BACKGROUND_COLOR);
        tablePanel.setBorder(new EmptyBorder(0, 0, 15, 15));
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        add(tablePanel, BorderLayout.CENTER);


        loadAssignedSections();
        addListeners();

        setVisible(true);
    }


    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);

        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(PRIMARY_COLOR, 1),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }


    private void styleTable(JTable table) {
        table.setRowHeight(35); // Slightly taller rows
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(230, 230, 230));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setShowVerticalLines(false); // Cleaner look


        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(0, 40));
        header.setDefaultRenderer((table1, value, isSelected, hasFocus, row, column) -> {
            JLabel label = new JLabel(value.toString());
            label.setOpaque(true);
            label.setBackground(PRIMARY_COLOR);
            label.setForeground(Color.WHITE);
            label.setFont(new Font("Segoe UI", Font.BOLD, 14));
            label.setHorizontalAlignment(SwingConstants.CENTER);
            return label;
        });
    }

    private void loadAssignedSections() {
        tableModel.setRowCount(0);

        if (instructorService != null) {
            List<Section> assignedSections = instructorService.getAssignedSections();
            for (Section section : assignedSections) {
                Object[] row = new Object[]{
                        section.getSectionId(),
                        section.course.getCode(),
                        section.course.getTitle(),
                        section.course.getCredits(),
                        section.getDay() + " " + section.getTime() + " (" + section.getRoom() + ")",
                        section.getCapacity()
                };
                tableModel.addRow(row);
            }
        }
    }

    private void addListeners() {

        ((JButton)navPanel.getComponent(0)).addActionListener(e -> loadAssignedSections());


        ((JButton)navPanel.getComponent(1)).addActionListener(e -> {
            if (checkSelection()) {
                int sectionId = getSelectedSectionId();
                String info = getSelectedCourseInfo();
                // Ensure ManageGradesDialog exists or comment this out
                new ManageGradesDialog(this, sectionId, info).setVisible(true);
            }
        });


        ((JButton)navPanel.getComponent(2)).addActionListener(e -> {
            if (checkSelection()) {
                int sectionId = getSelectedSectionId();
                new ComputeGradesDialog(this, sectionId).setVisible(true);
            }
        });


        ((JButton)navPanel.getComponent(3)).addActionListener(e -> {
            if (checkSelection()) {
                int sectionId = getSelectedSectionId();
                String info = getSelectedCourseInfo();
                new ViewStatisticsDialog(this, sectionId, info).setVisible(true);
            }
        });


        ((JButton)navPanel.getComponent(4)).addActionListener(e -> {
            new ChangePasswordDialog(this).setVisible(true);
        });


        ((JButton)navPanel.getComponent(5)).addActionListener(e -> {
            UserSession.getInstance().clearSession();
            JOptionPane.showMessageDialog(this, "Logged out successfully.");
            this.dispose();

            new LoginWindow();
        });
    }

    private int getSelectedSectionId() {
        return (int) tableModel.getValueAt(sectionTable.getSelectedRow(), 0);
    }

    private String getSelectedCourseInfo() {
        return tableModel.getValueAt(sectionTable.getSelectedRow(), 1) + " - " +
                tableModel.getValueAt(sectionTable.getSelectedRow(), 2);
    }

    private boolean checkSelection() {
        if (sectionTable.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(this, "Please select a section from the table first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}