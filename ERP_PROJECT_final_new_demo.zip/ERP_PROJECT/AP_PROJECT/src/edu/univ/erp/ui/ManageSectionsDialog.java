// File: edu.univ.erp.ui.ManageSectionsDialog.java

package edu.univ.erp.ui;

import edu.univ.erp.domain.Course;
import edu.univ.erp.service.AdminService;

import javax.swing.*;
import java.awt.*;
import java.util.Calendar;
import java.util.List;

public class ManageSectionsDialog extends JDialog {

    private AdminService adminService;


    private JComboBox<String> courseCombo;

    private JTextField capacityField;
    private JTextField roomField;
    private JComboBox<String> semesterComboBox;
    private JComboBox<String> dayComboBox;
    private JTextField timeField;
    private JTextField yearField;

    public ManageSectionsDialog(JFrame parent) {
        super(parent, "Admin: Section Management", true);
        this.adminService = new AdminService();

        setSize(600, 450);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));


        JPanel inputPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Create New Section"));


        capacityField = new JTextField(10);
        roomField = new JTextField(10);
        timeField = new JTextField(10);
        yearField = new JTextField(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));

        semesterComboBox = new JComboBox<>(new String[]{"Fall", "Spring", "Summer"});
        dayComboBox = new JComboBox<>(new String[]{"M", "Tu", "W", "Th", "F"});


        List<Course> courses = adminService.getAllCourses();
        courseCombo = new JComboBox<>();
        if (courses.isEmpty()) {
            courseCombo.addItem("No Courses Available");
        } else {
            for (Course c : courses) {

                courseCombo.addItem(c.getCourseId() + ": " + c.getCode() + " - " + c.getTitle());
            }
        }


        inputPanel.add(new JLabel("Select Course:"));
        inputPanel.add(courseCombo);
        inputPanel.add(new JLabel("Semester:"));
        inputPanel.add(semesterComboBox);
        inputPanel.add(new JLabel("Year:"));
        inputPanel.add(yearField);
        inputPanel.add(new JLabel("Day(s) (e.g., M/Tu/W):"));
        inputPanel.add(dayComboBox);
        inputPanel.add(new JLabel("Time (e.g., 10:00 AM - 11:30 AM):"));
        inputPanel.add(timeField);
        inputPanel.add(new JLabel("Room/Location:"));
        inputPanel.add(roomField);
        inputPanel.add(new JLabel("Capacity:"));
        inputPanel.add(capacityField);

        JButton createButton = new JButton("Create Section");
        inputPanel.add(new JLabel("")); // Spacer
        inputPanel.add(createButton);

        add(inputPanel, BorderLayout.NORTH);

        createButton.addActionListener(e -> handleCreateSection());

        setVisible(true);
    }

    private void handleCreateSection() {
        int courseId;
        int capacity;
        int year;
        String day = (String) dayComboBox.getSelectedItem();
        String semester = (String) semesterComboBox.getSelectedItem();
        String room = roomField.getText().trim();
        String time = timeField.getText().trim();
        String selectedCourse = (String) courseCombo.getSelectedItem();

        if (selectedCourse == null || selectedCourse.startsWith("No ")) {
            JOptionPane.showMessageDialog(this, "Please select a valid course.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {

            courseId = Integer.parseInt(selectedCourse.split(":")[0].trim());

            capacity = Integer.parseInt(capacityField.getText().trim());
            year = Integer.parseInt(yearField.getText().trim());


            if (capacity <= 0) {
                JOptionPane.showMessageDialog(this, "Capacity must be a positive number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Capacity and Year must be valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (time.isEmpty() || room.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Time and Room/Location must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }


        String result = adminService.createNewSection(courseId, day, time, room, capacity, semester, year);


        if (result.startsWith("SUCCESS")) {
            JOptionPane.showMessageDialog(this, result, "Section Creation Success", JOptionPane.INFORMATION_MESSAGE);

            capacityField.setText("");
            roomField.setText("");
            timeField.setText("");
        } else {
            JOptionPane.showMessageDialog(this, result, "Section Creation Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
}