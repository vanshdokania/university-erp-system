// File: edu.univ.erp.ui.StudentDashboard.java

package edu.univ.erp.ui;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.StudentService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.List;

public class StudentDashboard extends JFrame {

    private StudentService studentService;

    private JPanel mainContentPanel;
    private CardLayout cardLayout;
    private JPanel navPanel;

    private JTable catalogTable;
    private DefaultTableModel catalogTableModel;
    private JButton registerButton;

    private JTable gradesTable;
    private DefaultTableModel gradesTableModel;
    private JButton dropButton;
    private JButton downloadButton;

    private final Color PRIMARY_COLOR = new Color(65, 105, 225);
    private final Color BACKGROUND_COLOR = Color.WHITE;
    private final Color TEXT_COLOR = new Color(50, 50, 50);

    public StudentDashboard(String username) {
        this.studentService = new StudentService();

        setTitle("STUDENT Dashboard - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(BACKGROUND_COLOR);

        String role = UserSession.getInstance().getRole();
        JLabel welcomeLabel = new JLabel("Welcome, " + role + " " + username + "!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setForeground(TEXT_COLOR);
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(welcomeLabel, BorderLayout.NORTH);

        initSidebar();

        cardLayout = new CardLayout();
        mainContentPanel = new JPanel(cardLayout);
        mainContentPanel.setBackground(BACKGROUND_COLOR);
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        mainContentPanel.add(createCatalogPanel(), "CATALOG");
        mainContentPanel.add(createGradesPanel(), "GRADES");

        add(mainContentPanel, BorderLayout.CENTER);

        addListeners();
        loadCourseCatalog();
        loadMyRegistrations();

        setVisible(true);
    }

    private void initSidebar() {
        navPanel = new JPanel(new GridLayout(7, 1, 10, 15));
        navPanel.setBackground(BACKGROUND_COLOR);
        navPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Student Menu"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JButton btnCatalog = createStyledButton("Course Catalog");
        JButton btnMyCourses = createStyledButton("My Courses & Grades");
        JButton btnLogout = createStyledButton("Logout");


        btnLogout.setBackground(new Color(231, 76, 60));
        btnLogout.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) { btnLogout.setBackground(new Color(231, 76, 60).darker()); }
            public void mouseExited(MouseEvent evt) { btnLogout.setBackground(new Color(231, 76, 60)); }
        });

        btnCatalog.addActionListener(e -> {
            cardLayout.show(mainContentPanel, "CATALOG");
            loadCourseCatalog();
        });

        btnMyCourses.addActionListener(e -> {
            cardLayout.show(mainContentPanel, "GRADES");
            loadMyRegistrations();
        });

        btnLogout.addActionListener(e -> {
            UserSession.getInstance().clearSession();
            JOptionPane.showMessageDialog(this, "Logged out successfully.");
            this.dispose();
            new LoginWindow();
        });

        navPanel.add(btnCatalog);
        navPanel.add(btnMyCourses);
        navPanel.add(Box.createGlue());
        navPanel.add(btnLogout);

        JPanel westContainer = new JPanel(new BorderLayout());
        westContainer.setBackground(BACKGROUND_COLOR);
        westContainer.add(navPanel, BorderLayout.NORTH);
        westContainer.setPreferredSize(new Dimension(220, 0));

        add(westContainer, BorderLayout.WEST);
    }

    private JPanel createCatalogPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createTitledBorder("Available Courses"));

        String[] cols = {"Section ID", "Course Code", "Course Title", "Credits", "Schedule", "Capacity", "Semester", "Year"};
        catalogTableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        catalogTable = new JTable(catalogTableModel);
        styleTable(catalogTable);

        JScrollPane scroll = new JScrollPane(catalogTable);
        scroll.getViewport().setBackground(BACKGROUND_COLOR);
        panel.add(scroll, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setBackground(BACKGROUND_COLOR);

        registerButton = createStyledButton("Register for Selected Course");
        registerButton.setBackground(new Color(46, 204, 113)); // Green
        // Custom hover for green button
        registerButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) { registerButton.setBackground(new Color(46, 204, 113).darker()); }
            public void mouseExited(MouseEvent evt) { registerButton.setBackground(new Color(46, 204, 113)); }
        });

        btnPanel.add(registerButton);
        panel.add(btnPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createGradesPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createTitledBorder("My Registrations"));

        String[] cols = {"Section ID", "Course Code", "Course Title", "Credits", "Schedule", "Grade"};
        gradesTableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        gradesTable = new JTable(gradesTableModel);
        styleTable(gradesTable);

        JScrollPane scroll = new JScrollPane(gradesTable);
        scroll.getViewport().setBackground(BACKGROUND_COLOR);
        panel.add(scroll, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        btnPanel.setBackground(BACKGROUND_COLOR);

        downloadButton = createStyledButton("Download Transcript (CSV)");
        downloadButton.setBackground(new Color(52, 152, 219)); // Blue

        downloadButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) { downloadButton.setBackground(new Color(52, 152, 219).darker()); }
            public void mouseExited(MouseEvent evt) { downloadButton.setBackground(new Color(52, 152, 219)); }
        });

        dropButton = createStyledButton("Drop Selected Course");
        dropButton.setBackground(new Color(231, 76, 60)); // Red

        dropButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) { dropButton.setBackground(new Color(231, 76, 60).darker()); }
            public void mouseExited(MouseEvent evt) { dropButton.setBackground(new Color(231, 76, 60)); }
        });

        btnPanel.add(downloadButton);
        btnPanel.add(dropButton);
        panel.add(btnPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void loadCourseCatalog() {
        catalogTableModel.setRowCount(0);
        List<Section> catalog = studentService.getCourseCatalog();
        for (Section s : catalog) {
            catalogTableModel.addRow(new Object[]{
                    s.getSectionId(), s.course.getCode(), s.course.getTitle(), s.course.getCredits(),
                    s.getDay() + " " + s.getTime() + " (" + s.getRoom() + ")",
                    s.getCapacity(), s.getSemester(), s.getYear()
            });
        }
    }

    private void loadMyRegistrations() {
        gradesTableModel.setRowCount(0);
        List<Enrollment> list = studentService.getMyRegistrations();
        for (Enrollment e : list) {
            gradesTableModel.addRow(new Object[]{
                    e.getSectionId(), e.section.course.getCode(), e.section.course.getTitle(), e.section.course.getCredits(),
                    e.section.getSemester() + " " + e.section.getYear(),
                    e.getGrade() != null ? e.getGrade() : "In Progress"
            });
        }
    }

    private void addListeners() {
        registerButton.addActionListener(e -> handleRegistration());
        dropButton.addActionListener(e -> handleDrop());
        downloadButton.addActionListener(e -> handleDownload());
    }

    private void handleDownload() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Transcript as CSV");
        fileChooser.setSelectedFile(new File("transcript.csv"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            if (!fileToSave.getName().toLowerCase().endsWith(".csv")) {
                fileToSave = new File(fileToSave.getParentFile(), fileToSave.getName() + ".csv");
            }

            try {
                studentService.exportTranscript(fileToSave);
                JOptionPane.showMessageDialog(this, "Transcript saved successfully!\nPath: " + fileToSave.getAbsolutePath(), "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving transcript: " + ex.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    private void handleRegistration() {
        int selectedRow = catalogTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a course.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            int sectionId = (int) catalogTableModel.getValueAt(selectedRow, 0);
            String code = (String) catalogTableModel.getValueAt(selectedRow, 1);
            int confirm = JOptionPane.showConfirmDialog(this, "Register for " + code + "?", "Confirm", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                String result = studentService.registerForSection(sectionId);
                if (result.startsWith("SUCCESS")) {
                    JOptionPane.showMessageDialog(this, result, "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadMyRegistrations();
                } else {
                    JOptionPane.showMessageDialog(this, result, "Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void handleDrop() {
        int selectedRow = gradesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a course to drop.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            int sectionId = (int) gradesTableModel.getValueAt(selectedRow, 0);
            String code = (String) gradesTableModel.getValueAt(selectedRow, 1);
            int confirm = JOptionPane.showConfirmDialog(this, "Drop " + code + "?\nCannot be undone.", "Confirm", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                String result = studentService.dropSection(sectionId);
                if (result.startsWith("SUCCESS")) {
                    JOptionPane.showMessageDialog(this, result, "Dropped", JOptionPane.INFORMATION_MESSAGE);
                    loadMyRegistrations();
                } else {
                    JOptionPane.showMessageDialog(this, result, "Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                // 30 is the radius for rounded corners
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.dispose();
                super.paintComponent(g);
            }
        };

        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));


        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.getBackground().equals(PRIMARY_COLOR)) {
                    btn.setBackground(PRIMARY_COLOR.brighter());
                }
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.getBackground().equals(PRIMARY_COLOR.brighter())) {
                    btn.setBackground(PRIMARY_COLOR);
                }
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setGridColor(new Color(230, 230, 230));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setShowVerticalLines(false);
        JTableHeader header = table.getTableHeader();
        header.setDefaultRenderer((table1, value, isSelected, hasFocus, row, column) -> {
            JLabel label = new JLabel(value.toString());
            label.setOpaque(true);
            label.setBackground(PRIMARY_COLOR);
            label.setForeground(Color.WHITE);
            label.setFont(new Font("Segoe UI", Font.BOLD, 14));
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.WHITE));
            return label;
        });
    }
}