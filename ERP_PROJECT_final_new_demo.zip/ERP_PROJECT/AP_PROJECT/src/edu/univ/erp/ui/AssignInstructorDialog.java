package edu.univ.erp.ui;

import edu.univ.erp.domain.Instructor;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.AdminService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class AssignInstructorDialog extends JDialog {

    private AdminService adminService;
    private JComboBox<String> sectionCombo;
    private JComboBox<String> instructorCombo;

    public AssignInstructorDialog(JFrame parent) {
        super(parent, "Admin: Assign Instructor to Section", true);
        this.adminService = new AdminService();

        setSize(500, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(4, 1, 5, 15));
        inputPanel.setBorder(new EmptyBorder(20, 20, 20, 20));


        List<Section> sections = adminService.getAllSections();
        sectionCombo = new JComboBox<>();
        if (sections.isEmpty()) sectionCombo.addItem("No Sections Found");

        for (Section s : sections) {
            String code = (s.course != null) ? s.course.getCode() : "Unknown";
            String label = String.format("[%d] %s - %s %s", s.getSectionId(), code, s.getDay(), s.getTime());
            sectionCombo.addItem(label);
        }

        List<Instructor> instructors = adminService.getAllInstructors();
        instructorCombo = new JComboBox<>();
        if (instructors.isEmpty()) instructorCombo.addItem("No Instructors Found");

        for (Instructor i : instructors) {
            String label = String.format("[%d] %s (%s)", i.getInstructorId(), i.getUsername(), i.getDepartment());
            instructorCombo.addItem(label);
        }

        inputPanel.add(new JLabel("Select Section:"));
        inputPanel.add(sectionCombo);
        inputPanel.add(new JLabel("Select Instructor:"));
        inputPanel.add(instructorCombo);

        add(inputPanel, BorderLayout.CENTER);

        JButton assignButton = new JButton("Assign Instructor");
        assignButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        assignButton.setBackground(new Color(65, 105, 225)); // Blue
        assignButton.setForeground(Color.WHITE);
        assignButton.addActionListener(e -> handleAssignInstructor());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBorder(new EmptyBorder(0, 0, 15, 0));
        buttonPanel.add(assignButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void handleAssignInstructor() {
        String secStr = (String) sectionCombo.getSelectedItem();
        String instStr = (String) instructorCombo.getSelectedItem();

        if (secStr == null || instStr == null || secStr.startsWith("No ") || instStr.startsWith("No ")) {
            JOptionPane.showMessageDialog(this, "Please select valid options.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {

            int sectionId = Integer.parseInt(secStr.substring(secStr.indexOf('[') + 1, secStr.indexOf(']')));
            int instructorId = Integer.parseInt(instStr.substring(instStr.indexOf('[') + 1, instStr.indexOf(']')));

            String result = adminService.assignInstructor(sectionId, instructorId);

            if (result.startsWith("SUCCESS")) {
                JOptionPane.showMessageDialog(this, result, "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, result, "Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error processing selection: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}