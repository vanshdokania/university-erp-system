package edu.univ.erp.ui;

import edu.univ.erp.service.InstructorService;
import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class ViewStatisticsDialog extends JDialog {

    public ViewStatisticsDialog(JFrame parent, int sectionId, String courseName) {
        super(parent, "Statistics: " + courseName, true);
        setSize(400, 400);
        setLocationRelativeTo(parent);

        InstructorService service = new InstructorService();
        Map<String, Integer> stats = service.getGradeStatistics(sectionId);

        JTextArea statsArea = new JTextArea();
        statsArea.setEditable(false);
        statsArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        statsArea.setMargin(new Insets(10, 10, 10, 10));

        StringBuilder sb = new StringBuilder();
        sb.append("CLASS SUMMARY\n");
        sb.append("========================\n");
        sb.append("Total Enrolled: ").append(stats.get("Total Students")).append("\n");
        sb.append("Grades Submitted: ").append(stats.get("Graded")).append("\n\n");

        sb.append("GRADE DISTRIBUTION\n");
        sb.append("========================\n");


        String[] grades = {"A", "B", "C", "D", "F"};
        for (String g : grades) {
            if (stats.containsKey(g)) {
                sb.append("Grade ").append(g).append(": \t").append(stats.get(g)).append("\n");
            }
        }


        for (String key : stats.keySet()) {
            if (!key.equals("Total Students") && !key.equals("Graded") && !isStandard(key)) {
                sb.append(key).append(": \t").append(stats.get(key)).append("\n");
            }
        }

        statsArea.setText(sb.toString());
        add(new JScrollPane(statsArea));
        setVisible(true);
    }

    private boolean isStandard(String g) {
        return "A".equals(g) || "B".equals(g) || "C".equals(g) || "D".equals(g) || "F".equals(g);
    }
}