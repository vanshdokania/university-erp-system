package edu.univ.erp.ui;

import edu.univ.erp.service.AdminService;

import javax.swing.*;
import java.awt.*;

public class ManageUsersDialog extends JDialog {

    private AdminService adminService;

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;

    private JPanel dynamicPanel;
    private CardLayout cardLayout;

    private JTextField rollNoField;
    private JTextField programField;
    private JTextField yearField;
    private JPanel studentPanel;

    private JTextField departmentField;
    private JPanel instructorPanel;

    public ManageUsersDialog(JFrame parent) {
        super(parent, "Admin: Create New User", true);
        this.adminService = new AdminService();

        setSize(550, 450);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JPanel mainInputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        ThemeManager.applyTheme(mainInputPanel);
        mainInputPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(ThemeManager.getBorderColor()),
            "User Credentials",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 13)
        ));
        ((javax.swing.border.TitledBorder) mainInputPanel.getBorder()).setTitleColor(ThemeManager.getTextColor());

        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");
        JLabel roleLabel = new JLabel("Role:");
        ThemeManager.applyTheme(userLabel);
        ThemeManager.applyTheme(passLabel);
        ThemeManager.applyTheme(roleLabel);

        usernameField = new JTextField(15);
        passwordField = new JPasswordField(15);
        roleComboBox = new JComboBox<>(new String[]{"Student", "Instructor"});
        roleComboBox.setBackground(ThemeManager.getInputBackground());
        roleComboBox.setForeground(ThemeManager.getTextColor());
        roleComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        ThemeManager.applyTheme(usernameField);
        ThemeManager.applyTheme(passwordField);

        mainInputPanel.add(userLabel);
        mainInputPanel.add(usernameField);
        mainInputPanel.add(passLabel);
        mainInputPanel.add(passwordField);
        mainInputPanel.add(roleLabel);
        mainInputPanel.add(roleComboBox);

        add(mainInputPanel, BorderLayout.NORTH);

        cardLayout = new CardLayout();
        dynamicPanel = new JPanel(cardLayout);
        ThemeManager.applyTheme(dynamicPanel);
        dynamicPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(ThemeManager.getBorderColor()),
            "Profile Details",
            0, 0,
            new Font("Segoe UI", Font.BOLD, 13)
        ));
        ((javax.swing.border.TitledBorder) dynamicPanel.getBorder()).setTitleColor(ThemeManager.getTextColor());

        setupStudentPanel();
        setupInstructorPanel();

        dynamicPanel.add(studentPanel, "Student");
        dynamicPanel.add(instructorPanel, "Instructor");

        roleComboBox.addActionListener(e -> {
            cardLayout.show(dynamicPanel, (String) roleComboBox.getSelectedItem());
            revalidate();
        });

        add(dynamicPanel, BorderLayout.CENTER);

        JButton createButton = new JButton("Create User");
        createButton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        ThemeManager.applyTheme(createButton);
        createButton.addActionListener(e -> handleCreateUser());

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        ThemeManager.applyTheme(controlPanel);
        controlPanel.add(createButton);
        add(controlPanel, BorderLayout.SOUTH);


        getContentPane().setBackground(ThemeManager.getBackground());


        cardLayout.show(dynamicPanel, "Student");

        setVisible(true);
    }

    private void setupStudentPanel() {
        studentPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        ThemeManager.applyTheme(studentPanel);
        
        rollNoField = new JTextField(15);
        programField = new JTextField(15);
        yearField = new JTextField(15);
        
        ThemeManager.applyTheme(rollNoField);
        ThemeManager.applyTheme(programField);
        ThemeManager.applyTheme(yearField);

        JLabel rollLabel = new JLabel("Roll No (e.g., S0001):");
        JLabel progLabel = new JLabel("Program:");
        JLabel yearLabel = new JLabel("Admission Year:");
        ThemeManager.applyTheme(rollLabel);
        ThemeManager.applyTheme(progLabel);
        ThemeManager.applyTheme(yearLabel);

        studentPanel.add(rollLabel);
        studentPanel.add(rollNoField);
        studentPanel.add(progLabel);
        studentPanel.add(programField);
        studentPanel.add(yearLabel);
        studentPanel.add(yearField);
    }

    private void setupInstructorPanel() {
        instructorPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        ThemeManager.applyTheme(instructorPanel);
        
        departmentField = new JTextField(15);
        ThemeManager.applyTheme(departmentField);

        JLabel deptLabel = new JLabel("Department:");
        ThemeManager.applyTheme(deptLabel);

        instructorPanel.add(deptLabel);
        instructorPanel.add(departmentField);
    }

    private void handleCreateUser() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String role = (String) roleComboBox.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and Password fields cannot be empty.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String result;

        if ("Student".equals(role)) {
            String rollNo = rollNoField.getText().trim();
            String program = programField.getText().trim();
            String yearText = yearField.getText().trim();

            if (rollNo.isEmpty() || program.isEmpty() || yearText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All Student profile fields must be filled.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                Integer.parseInt(yearText);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Admission Year must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            result = adminService.createNewUser(username, password, role, rollNo, program, yearText);

        } else if ("Instructor".equals(role)) {
            String department = departmentField.getText().trim();

            if (department.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Department field cannot be empty.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }


            result = adminService.createNewUser(username, password, role, department);
        } else {
            result = "FAILURE: Invalid role selected.";
        }


        if (result.startsWith("SUCCESS")) {
            JOptionPane.showMessageDialog(this, result, "User Creation Success", JOptionPane.INFORMATION_MESSAGE);

            usernameField.setText("");
            passwordField.setText("");
            rollNoField.setText("");
            programField.setText("");
            yearField.setText("");
            departmentField.setText("");
        } else {
            JOptionPane.showMessageDialog(this, result, "User Creation Failed", JOptionPane.ERROR_MESSAGE);
        }
    }
}