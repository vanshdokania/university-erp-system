// File: edu.univ.erp.ui.SystemSettingsDialog.java

package edu.univ.erp.ui;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SystemSettingsDialog extends JDialog {

    private final Color PRIMARY_COLOR = new Color(65, 105, 225);
    private final Color BACKGROUND_COLOR = Color.WHITE;

    public SystemSettingsDialog(JFrame parent) {
        super(parent, "System Settings & Logs", true);
        setSize(600, 500);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(BACKGROUND_COLOR);

        // Header
        JLabel titleLabel = new JLabel("System Event Logs", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(50, 50, 50));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        add(titleLabel, BorderLayout.NORTH);

        // Logs Area
        JTextArea logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        logArea.setText(generateMockLogs());
        logArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        // Add padding panel
        JPanel scrollContainer = new JPanel(new BorderLayout());
        scrollContainer.setBackground(BACKGROUND_COLOR);
        scrollContainer.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 15));
        scrollContainer.add(scrollPane, BorderLayout.CENTER);

        add(scrollContainer, BorderLayout.CENTER);

        // Close Button
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        closeButton.setBackground(PRIMARY_COLOR);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        closeButton.addActionListener(e -> dispose());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.setBackground(BACKGROUND_COLOR);
        btnPanel.add(closeButton);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private String generateMockLogs() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        StringBuilder logs = new StringBuilder();

        logs.append("[").append(dtf.format(LocalDateTime.now().minusHours(4))).append("] [INFO] System Boot Sequence Initiated.\n");
        logs.append("[").append(dtf.format(LocalDateTime.now().minusHours(4))).append("] [INFO] Database Connection Established.\n");
        logs.append("[").append(dtf.format(LocalDateTime.now().minusHours(3))).append("] [INFO] User 'admin1' logged in successfully.\n");
        logs.append("[").append(dtf.format(LocalDateTime.now().minusHours(2))).append("] [WARN] Failed login attempt for user 'unknown'.\n");
        logs.append("[").append(dtf.format(LocalDateTime.now().minusMinutes(45))).append("] [INFO] New Section created: Course ID 101.\n");
        logs.append("[").append(dtf.format(LocalDateTime.now().minusMinutes(30))).append("] [INFO] Student 'stu1' registered for Section 1.\n");
        logs.append("[").append(dtf.format(LocalDateTime.now().minusMinutes(10))).append("] [INFO] Admin accessed System Settings.\n");

        return logs.toString();
    }
}