package edu.univ.erp.service;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.data.SectionDAO;
import edu.univ.erp.data.EnrollmentDAO;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Enrollment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InstructorService {

    private SectionDAO sectionDAO;
    private EnrollmentDAO enrollmentDAO;

    public InstructorService() {
        this.sectionDAO = new SectionDAO();
        this.enrollmentDAO = new EnrollmentDAO();
    }

    public List<Section> getAssignedSections() {
        if (!"Instructor".equals(UserSession.getInstance().getRole())) {
            return List.of();
        }
        int instructorId = UserSession.getInstance().getProfileId();
        return sectionDAO.getSectionsByInstructorId(instructorId);
    }

    public List<Enrollment> getEnrolledStudents(int sectionId) {
        if (!"Instructor".equals(UserSession.getInstance().getRole())) {
            return List.of();
        }
        return enrollmentDAO.getEnrolledStudentsBySection(sectionId);
    }

    public String submitGrade(int enrollmentId, String grade) {
        if (!"Instructor".equals(UserSession.getInstance().getRole())) {
            return "FAILURE: Only instructors can submit grades.";
        }
        String cleanGrade = grade != null ? grade.trim().toUpperCase() : null;
        if (cleanGrade == null || cleanGrade.isEmpty() || cleanGrade.length() > 3) {
            return "FAILURE: Invalid grade format.";
        }
        if (enrollmentDAO.updateGrade(enrollmentId, cleanGrade)) {
            return "SUCCESS: Grade '" + cleanGrade + "' submitted.";
        } else {
            return "FAILURE: Grade submission failed.";
        }
    }
    public double computeFinalGrade(double quiz, double mid, double end) {
        if (quiz < 0 || mid < 0 || end < 0) {
            throw new IllegalArgumentException("Grades cannot be negative");
        }

        return (quiz * 0.20) + (mid * 0.30) + (end * 0.50);
    }

    public Map<String, Integer> getGradeStatistics(int sectionId) {
        List<Enrollment> students = getEnrolledStudents(sectionId);
        Map<String, Integer> stats = new HashMap<>();

        stats.put("Total Students", students.size());
        stats.put("Graded", 0);

        for (Enrollment e : students) {
            String g = e.getGrade();
            if (g != null && !g.trim().isEmpty()) {
                stats.put("Graded", stats.get("Graded") + 1);

                stats.put(g, stats.getOrDefault(g, 0) + 1);
            }
        }
        return stats;
    }
}