// File: edu.univ.erp.service.StudentService.java

package edu.univ.erp.service;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.data.SectionDAO;
import edu.univ.erp.data.EnrollmentDAO;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Enrollment;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class StudentService {

    private EnrollmentDAO enrollmentDAO;
    private SectionDAO sectionDAO;
    private AdminService adminService;


    private static final LocalDate REGISTRATION_DEADLINE = LocalDate.of(2025, 12, 31);

    public StudentService() {
        this.enrollmentDAO = new EnrollmentDAO();
        this.sectionDAO = new SectionDAO();
        this.adminService = new AdminService();
    }

    public String getDeadlineString() {
        return REGISTRATION_DEADLINE.format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"));
    }

    private boolean isPastDeadline() {
        return LocalDate.now().isAfter(REGISTRATION_DEADLINE);
    }


    public List<Section> getCourseCatalog() {
        if (!"Student".equals(UserSession.getInstance().getRole())) {
            return List.of();
        }
        return sectionDAO.getAllSections();
    }

    public String registerForSection(int sectionId) {
        if (!"Student".equals(UserSession.getInstance().getRole())) {
            return "FAILURE: Only students can register.";
        }

        if (adminService.isMaintenanceModeEnabled()) {
            return "FAILURE: Maintenance Mode is ON. Registration is blocked.";
        }


        if (isPastDeadline()) {
            return "FAILURE: Registration deadline passed (" + getDeadlineString() + ").";
        }

        int studentId = UserSession.getInstance().getProfileId();

        if (enrollmentDAO.isStudentEnrolled(studentId, sectionId)) {
            return "FAILURE: You are already registered for this section.";
        }

        if (enrollmentDAO.registerStudent(studentId, sectionId)) {
            return "SUCCESS: Registered for Section " + sectionId;
        } else {
            return "FAILURE: Database error during registration.";
        }
    }

    public String dropSection(int sectionId) {
        if (!"Student".equals(UserSession.getInstance().getRole())) {
            return "FAILURE: Only students can drop sections.";
        }


        if (adminService.isMaintenanceModeEnabled()) {
            return "FAILURE: Maintenance Mode is ON. Dropping is blocked.";
        }

        if (isPastDeadline()) {
            return "FAILURE: Drop deadline passed (" + getDeadlineString() + "). Withdrawals are no longer allowed.";
        }

        int studentId = UserSession.getInstance().getProfileId();

        if (!enrollmentDAO.isStudentEnrolled(studentId, sectionId)) {
            return "FAILURE: You are not enrolled in Section " + sectionId + ".";
        }

        if (enrollmentDAO.deleteEnrollment(studentId, sectionId)) {
            return "SUCCESS: Section dropped successfully.";
        } else {
            return "FAILURE: Drop failed. Database error.";
        }
    }

    public List<Enrollment> getMyRegistrations() {
        if (!"Student".equals(UserSession.getInstance().getRole())) {
            return List.of();
        }
        int studentId = UserSession.getInstance().getProfileId();
        return enrollmentDAO.getMyRegistrations(studentId);
    }

    public void exportTranscript(File file) throws IOException {
        List<Enrollment> enrollments = getMyRegistrations();

        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            writer.println("Course Code,Course Title,Credits,Semester,Year,Grade");
            for (Enrollment e : enrollments) {
                Section s = e.section;
                String code = (s.course != null) ? s.course.getCode() : "N/A";
                String title = (s.course != null) ? s.course.getTitle().replace(",", " ") : "N/A";
                double credits = (s.course != null) ? s.course.getCredits() : 0.0;
                String grade = (e.getGrade() != null) ? e.getGrade() : "In Progress";

                writer.printf("%s,%s,%.1f,%s,%d,%s%n",
                        code, title, credits, s.getSemester(), s.getYear(), grade);
            }
        }
    }



    public boolean checkAvailability(Section section) {
        return section.getCapacity() > 0;
    }
}