package edu.univ.erp.service;

import edu.univ.erp.auth.AuthService;
import edu.univ.erp.auth.UserSession;
import edu.univ.erp.data.SystemDAO;
import edu.univ.erp.data.UserDAO;
import edu.univ.erp.data.CourseDAO;
import edu.univ.erp.data.SectionDAO;
import edu.univ.erp.data.EnrollmentDAO;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Instructor;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Course; // ADDED
import java.util.List;

public class AdminService {

    private SystemDAO systemDAO;
    private AuthService authService;
    private UserDAO userDAO;
    private CourseDAO courseDAO;
    private SectionDAO sectionDAO;
    private EnrollmentDAO enrollmentDAO;

    public AdminService() {
        this.systemDAO = new SystemDAO();
        this.authService = new AuthService();
        this.userDAO = new UserDAO();
        this.courseDAO = new CourseDAO();
        this.sectionDAO = new SectionDAO();
        this.enrollmentDAO = new EnrollmentDAO();
    }

    // --- Helper Methods for Dropdowns ---
    public List<Instructor> getAllInstructors() {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return List.of();
        return userDAO.getAllInstructors();
    }

    public List<Section> getAllSections() {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return List.of();
        return sectionDAO.getAllSections();
    }

    public List<Course> getAllCourses() {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return List.of();
        return courseDAO.getAllCourses();
    }

    public String toggleMaintenanceMode(boolean enabled) {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return "FAILURE: Unauthorized.";
        if (systemDAO.setMaintenanceMode(enabled)) return "SUCCESS: Maintenance Mode " + (enabled ? "ON" : "OFF");
        return "ERROR: Database update failed.";
    }

    public boolean isMaintenanceModeEnabled() { return systemDAO.isMaintenanceModeEnabled(); }

    public String createNewUser(String username, String password, String role, String... details) {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return "FAILURE: Unauthorized.";
        int uid = authService.createBaseUser(username, password, role);
        if (uid == -1) return "FAILURE: Auth DB Error.";

        boolean success = false;
        if ("Student".equalsIgnoreCase(role)) success = userDAO.createStudentProfile(uid, details[0], details[1], Integer.parseInt(details[2]));
        else if ("Instructor".equalsIgnoreCase(role)) success = userDAO.createInstructorProfile(uid, details[0]);

        return success ? "SUCCESS: User created." : "FAILURE: Profile creation error.";
    }

    public String createNewCourse(String code, String title, double credits) {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return "FAILURE: Unauthorized.";
        if (courseDAO.createCourse(code, title, credits)) return "SUCCESS: Course created.";
        return "FAILURE: Database error.";
    }

    public String createNewSection(int cid, String day, String time, String room, int cap, String sem, int year) {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return "FAILURE: Unauthorized.";
        if (sectionDAO.createSection(cid, day, time, room, cap, sem, year)) return "SUCCESS: Section created.";
        return "FAILURE: Database error.";
    }

    public String assignInstructor(int sectionId, int instructorId) {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return "FAILURE: Unauthorized.";
        if (sectionDAO.assignInstructorToSection(sectionId, instructorId)) return "SUCCESS: Instructor assigned.";
        return "FAILURE: Database error.";
    }

    public List<Enrollment> viewAllEnrollments() {
        if (!"Admin".equals(UserSession.getInstance().getRole())) return List.of();
        return enrollmentDAO.getAllEnrollments();
    }
    private static boolean maintenanceMode = false; // Static to simulate global state

    public boolean isMaintenanceMode() {
        return maintenanceMode;
    }

    public void setMaintenanceMode(boolean status) {
        maintenanceMode = status;
    }
}