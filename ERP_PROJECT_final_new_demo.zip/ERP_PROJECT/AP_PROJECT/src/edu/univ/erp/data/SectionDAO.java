// File: edu.univ.erp.data.SectionDAO.java (FINAL FIXED VERSION)

package edu.univ.erp.data;

import edu.univ.erp.domain.Course;
import edu.univ.erp.domain.Section;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SectionDAO {


    public List<Section> getAllSections() {
        List<Section> sections = new ArrayList<>();


        final String SQL = "SELECT s.section_id, s.capacity, s.semester, s.year, " +
                "s.day, s.time, s.room, " +
                "c.course_id, c.code, c.title, c.credits, " +
                "s.instructor_id, i.department " + // Select s.instructor_id, not i.instructor_id
                "FROM sections s " +
                "JOIN courses c ON s.course_id = c.course_id " +
                "LEFT JOIN instructors i ON s.instructor_id = i.user_id " + // FIX: Join on user_id
                "LIMIT 100";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Course course = new Course(
                        rs.getInt("course_id"),
                        rs.getString("code"),
                        rs.getString("title"),
                        rs.getDouble("credits")
                );

                Section section = new Section(
                        rs.getInt("section_id"),
                        rs.getInt("course_id"),
                        rs.getInt("instructor_id"), // Gets ID from sections table
                        rs.getString("day"),
                        rs.getString("time"),
                        rs.getString("room"),
                        rs.getInt("capacity"),
                        rs.getString("semester"),
                        rs.getInt("year")
                );

                section.course = course;
                sections.add(section);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving course catalog: " + e.getMessage());
        }
        return sections;
    }


    public boolean createSection(int courseId, String day, String time, String room, int capacity, String semester, int year) {
        final String SQL = "INSERT INTO sections (course_id, instructor_id, day, time, room, capacity, semester, year) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {

            stmt.setInt(1, courseId);
            stmt.setNull(2, java.sql.Types.INTEGER);
            stmt.setString(3, day);
            stmt.setString(4, time);
            stmt.setString(5, room);
            stmt.setInt(6, capacity);
            stmt.setString(7, semester);
            stmt.setInt(8, year);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating new section: " + e.getMessage());
            return false;
        }
    }

    public boolean assignInstructorToSection(int sectionId, int instructorId) {
        final String SQL = "UPDATE sections SET instructor_id = ? WHERE section_id = ?";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {

            stmt.setInt(1, instructorId);
            stmt.setInt(2, sectionId);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error assigning instructor to section: " + e.getMessage());
            return false;
        }
    }

    public List<Section> getSectionsByInstructorId(int instructorId) {
        List<Section> sections = new ArrayList<>();
        final String SQL = "SELECT s.section_id, s.capacity, s.semester, s.year, " +
                "s.day, s.time, s.room, " +
                "c.course_id, c.code, c.title, c.credits " +
                "FROM sections s " +
                "JOIN courses c ON s.course_id = c.course_id " +
                "WHERE s.instructor_id = ?";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {

            stmt.setInt(1, instructorId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Course course = new Course(
                            rs.getInt("course_id"),
                            rs.getString("code"),
                            rs.getString("title"),
                            rs.getDouble("credits")
                    );

                    Section section = new Section(
                            rs.getInt("section_id"),
                            rs.getInt("course_id"),
                            instructorId,
                            rs.getString("day"),
                            rs.getString("time"),
                            rs.getString("room"),
                            rs.getInt("capacity"),
                            rs.getString("semester"),
                            rs.getInt("year")
                    );

                    section.course = course;
                    sections.add(section);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving assigned sections for instructor " + instructorId + ": " + e.getMessage());
        }
        return sections;
    }
}