// File: edu.univ.erp.data.UserDAO.java

package edu.univ.erp.data;

import edu.univ.erp.domain.User;
import edu.univ.erp.domain.Student;
import edu.univ.erp.domain.Instructor;

import java.sql.*;
import java.util.ArrayList; // ADDED
import java.util.List;      // ADDED

public class UserDAO {


    public User getUserByUsername(String username) {
        final String SQL = "SELECT user_id, username, role FROM users_auth WHERE username = ?";
        try (Connection conn = DBConnection.getAuthDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(rs.getInt("user_id"), rs.getString("username"), rs.getString("role"));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public Student getStudentProfile(User baseUser) {
        if (!"Student".equals(baseUser.getRole())) return null;
        final String SQL = "SELECT * FROM students WHERE user_id = ?";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setInt(1, baseUser.getUserId());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Uses the 7-arg constructor (reverted version)
                    return new Student(
                            baseUser.getUserId(), baseUser.getUsername(), baseUser.getRole(),
                            rs.getInt("user_id"), rs.getString("roll_no"), rs.getString("program"), rs.getInt("year")
                    );
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public Instructor getInstructorProfile(User baseUser) {
        if (!"Instructor".equals(baseUser.getRole())) return null;
        final String SQL = "SELECT * FROM instructors WHERE user_id = ?";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setInt(1, baseUser.getUserId());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Instructor(
                            baseUser.getUserId(), baseUser.getUsername(), baseUser.getRole(),
                            rs.getInt("user_id"), rs.getString("department")
                    );
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public User getAdminProfile(User baseUser) { return baseUser; }

    // --- NEW METHOD: Get All Instructors for Dropdown ---
    public List<Instructor> getAllInstructors() {
        List<Instructor> instructors = new ArrayList<>();
        // Cross-Database Join: Fetch instructor details + username
        final String SQL = "SELECT i.user_id, i.department, u.username, u.role " +
                "FROM instructors i " +
                "JOIN university_auth_db.users_auth u ON i.user_id = u.user_id " +
                "ORDER BY u.username ASC";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                instructors.add(new Instructor(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("role"),
                        rs.getInt("user_id"), // Instructor ID is the User ID
                        rs.getString("department")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error listing instructors: " + e.getMessage());
        }
        return instructors;
    }


    public boolean createStudentProfile(int userId, String rollNo, String program, int year) {
        final String SQL = "INSERT INTO students (user_id, roll_no, program, year) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setInt(1, userId); stmt.setString(2, rollNo); stmt.setString(3, program); stmt.setInt(4, year);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean createInstructorProfile(int userId, String department) {
        final String SQL = "INSERT INTO instructors (user_id, department) VALUES (?, ?)";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setInt(1, userId); stmt.setString(2, department);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
}