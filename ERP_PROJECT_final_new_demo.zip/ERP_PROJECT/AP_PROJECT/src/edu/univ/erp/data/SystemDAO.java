// File: edu.univ.erp.data.SystemDAO.java

package edu.univ.erp.data;

import java.sql.*;


public class SystemDAO {

    private static final String MAINTENANCE_KEY = "maintenance_on";

    public boolean isMaintenanceModeEnabled() {
        final String SQL = "SELECT value FROM settings WHERE key_name = ?";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {

            stmt.setString(1, MAINTENANCE_KEY);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Check for "true" (case-insensitive)
                    return "true".equalsIgnoreCase(rs.getString("value"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error reading Maintenance Mode flag: " + e.getMessage());
        }
        return false;
    }

    public boolean setMaintenanceMode(boolean enabled) {
        final String newValue = enabled ? "true" : "false";
        final String SQL = "UPDATE settings SET value = ? WHERE key_name = ?";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {

            stmt.setString(1, newValue);
            stmt.setString(2, MAINTENANCE_KEY);

            // If executeUpdate returns > 0, the row was found and updated
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating Maintenance Mode flag: " + e.getMessage());
            return false;
        }
    }
}