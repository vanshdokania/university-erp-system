// File: edu.univ.erp.data.EnrollmentDAO.java

package edu.univ.erp.data;

import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Student;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Course;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {


    public List<Enrollment> getEnrolledStudentsBySection(int sectionId) {
        List<Enrollment> enrollments = new ArrayList<>();

        final String SQL = "SELECT e.enrollment_id, e.grade, e.student_id, " +
                "u.user_id, u.username, " +
                "s.roll_no, s.program, s.year " +
                "FROM enrollments e " +
                "LEFT JOIN students s ON e.student_id = s.user_id " +
                "LEFT JOIN university_auth_db.users_auth u ON e.student_id = u.user_id " + // <--- FIX HERE
                "WHERE e.section_id = ? AND e.status = 'Registered'";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {

            stmt.setInt(1, sectionId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String username = rs.getString("username");
                    String rollNo = rs.getString("roll_no");

                    if (username == null) username = "Student #" + rs.getInt("student_id");
                    if (rollNo == null) rollNo = "N/A";

                    Student student = new Student(
                            rs.getInt("student_id"),
                            username,
                            "Student",
                            rs.getInt("student_id"),
                            rollNo,
                            rs.getString("program"),
                            rs.getInt("year")
                    );

                    Enrollment enrollment = new Enrollment(
                            rs.getInt("enrollment_id"),
                            rs.getInt("student_id"),
                            sectionId,
                            rs.getString("grade")
                    );

                    enrollment.student = student;
                    enrollments.add(enrollment);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving roster: " + e.getMessage());
            e.printStackTrace();
        }
        return enrollments;
    }

    public List<Enrollment> getMyRegistrations(int studentId) {
        List<Enrollment> enrollments = new ArrayList<>();


        final String SQL = "SELECT * FROM enrollments WHERE student_id = ? AND status = 'Registered'";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {

            stmt.setInt(1, studentId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int enrollmentId = rs.getInt("enrollment_id");
                    int sectionId = rs.getInt("section_id");
                    String grade = rs.getString("grade");

                    Enrollment enrollment = new Enrollment(enrollmentId, studentId, sectionId, grade);
                    fillSectionDetails(conn, enrollment, sectionId);
                    enrollments.add(enrollment);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return enrollments;
    }

    private void fillSectionDetails(Connection conn, Enrollment enrollment, int sectionId) {
        String sql = "SELECT s.semester, s.year, s.day, s.time, s.room, " +
                "c.course_id, c.code, c.title, c.credits " +
                "FROM sections s " +
                "LEFT JOIN courses c ON s.course_id = c.course_id " +
                "WHERE s.section_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, sectionId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Course course = new Course(
                            rs.getInt("course_id"),
                            rs.getString("code"),
                            rs.getString("title"),
                            rs.getDouble("credits")
                    );
                    Section section = new Section(
                            sectionId, rs.getInt("course_id"), -1,
                            rs.getString("day"), rs.getString("time"), rs.getString("room"),
                            -1, rs.getString("semester"), rs.getInt("year")
                    );
                    section.course = course;
                    enrollment.section = section;
                } else {
                    createPlaceholderSection(enrollment, sectionId, "Unknown Section");
                }
            }
        } catch (SQLException e) {
            createPlaceholderSection(enrollment, sectionId, "Error Fetching Data");
        }
    }

    private void createPlaceholderSection(Enrollment enrollment, int sectionId, String msg) {
        Course course = new Course(0, msg, "N/A", 0.0);
        Section section = new Section(sectionId, 0, 0, "", "", "", 0, "", 0);
        section.course = course;
        enrollment.section = section;
    }


    public List<Enrollment> getAllEnrollments() {
        List<Enrollment> enrollments = new ArrayList<>();

        final String SQL = "SELECT e.enrollment_id, e.grade, e.status, " +
                "st.user_id, u.username as student_name, " +
                "s.section_id, s.semester, s.year, " +
                "c.code, c.title " +
                "FROM enrollments e " +
                "LEFT JOIN students st ON e.student_id = st.user_id " +
                "LEFT JOIN university_auth_db.users_auth u ON st.user_id = u.user_id " + // <--- FIX
                "LEFT JOIN sections s ON e.section_id = s.section_id " +
                "LEFT JOIN courses c ON s.course_id = c.course_id " +
                "ORDER BY s.year DESC, s.semester, c.code";

        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Student student = new Student(
                        rs.getInt("user_id"),
                        rs.getString("student_name"),
                        "Student",
                        rs.getInt("user_id"),
                        "", "", 0
                );

                Course course = new Course(0, rs.getString("code"), rs.getString("title"), 0.0);
                Section section = new Section(rs.getInt("section_id"), 0, 0, "", "", "", 0, rs.getString("semester"), rs.getInt("year"));
                section.course = course;

                Enrollment enrollment = new Enrollment(
                        rs.getInt("enrollment_id"),
                        rs.getInt("user_id"),
                        rs.getInt("section_id"),
                        rs.getString("grade")
                );
                enrollment.setStatus(rs.getString("status"));
                enrollment.student = student;
                enrollment.section = section;

                enrollments.add(enrollment);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all enrollments: " + e.getMessage());
        }
        return enrollments;
    }



    public boolean isStudentEnrolled(int studentId, int sectionId) {
        final String SQL = "SELECT 1 FROM enrollments WHERE student_id = ? AND section_id = ? AND status = 'Registered'";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, sectionId);
            try (ResultSet rs = stmt.executeQuery()) { return rs.next(); }
        } catch (SQLException e) { return false; }
    }

    public boolean deleteEnrollment(int studentId, int sectionId) {
        final String SQL = "DELETE FROM enrollments WHERE student_id = ? AND section_id = ?";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, sectionId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) { return false; }
    }

    public boolean registerStudent(int studentId, int sectionId) {
        final String SQL = "INSERT INTO enrollments (student_id, section_id, status) VALUES (?, ?, 'Registered')";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, sectionId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "DB Error: " + e.getMessage());
            return false;
        }
    }

    public boolean updateGrade(int enrollmentId, String grade) {
        final String SQL = "UPDATE enrollments SET grade = ? WHERE enrollment_id = ?";
        try (Connection conn = DBConnection.getERPDBConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL)) {
            stmt.setString(1, grade);
            stmt.setInt(2, enrollmentId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) { return false; }
    }
}