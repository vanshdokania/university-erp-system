

package edu.univ.erp.domain;

public class Student extends User {
    private int studentId; // Added back
    private String rollNo;
    private String program;
    private int year;


    public Student(int userId, String username, String role,
                   int studentId, String rollNo, String program, int year) {
        super(userId, username, role);
        this.studentId = studentId;
        this.rollNo = rollNo;
        this.program = program;
        this.year = year;
    }

    public int getStudentId() { return studentId; }
    public String getRollNo() { return rollNo; }
    public String getProgram() { return program; }
    public int getYear() { return year; }

    public void setStudentId(int studentId) { this.studentId = studentId; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }
    public void setProgram(String program) { this.program = program; }
    public void setYear(int year) { this.year = year; }
}