package edu.univ.erp.domain;


public class Instructor extends User {
    private int instructorId;
    private String department;


    public Instructor(int userId, String username, String role,
                      int instructorId, String department) {
        super(userId, username, role);
        this.instructorId = instructorId;
        this.department = department;
    }

    public int getInstructorId() { return instructorId; }
    public String getDepartment() { return department; }

    public void setInstructorId(int instructorId) { this.instructorId = instructorId; }
    public void setDepartment(String department) { this.department = department; }
}