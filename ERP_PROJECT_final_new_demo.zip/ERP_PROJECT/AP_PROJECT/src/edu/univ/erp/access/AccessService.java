// File: edu.univ.erp.access.AccessService.java

package edu.univ.erp.access;

import edu.univ.erp.auth.UserSession;
import edu.univ.erp.data.SystemDAO;
import edu.univ.erp.domain.User;
import edu.univ.erp.domain.Instructor;
import edu.univ.erp.domain.Student;

import javax.swing.JOptionPane; // Used for quick error messages

public class AccessService {

    private SystemDAO systemDAO;

    public AccessService() {
        this.systemDAO = new SystemDAO();
    }


    public boolean checkMaintenanceMode(String actionName) {
        User user = UserSession.getInstance().getCurrentUser();
        if (user == null || "Admin".equals(user.getRole())) {
            // Admins are exempt from Maintenance Mode checks
            return false;
        }

        if (systemDAO.isMaintenanceModeEnabled()) {
            JOptionPane.showMessageDialog(null,
                    "System is currently in Maintenance Mode (View-Only). " + actionName + " is blocked.",
                    "Access Denied",
                    JOptionPane.WARNING_MESSAGE);
            return true;
        }
        return false;
    }

    public boolean isStudentAuthorized(String targetRollNo) {
        User user = UserSession.getInstance().getCurrentUser();

        if (user instanceof Student) {
            Student student = (Student) user;
            if (student.getRollNo().equals(targetRollNo)) {
                return true;
            }
        }

        JOptionPane.showMessageDialog(null,
                "Access Denied: You are not authorized to modify records for Roll No: " + targetRollNo + ".",
                "Authorization Failure",
                JOptionPane.ERROR_MESSAGE);
        return false;
    }


    public boolean isInstructorAssignedToSection(int sectionId) {

        User user = UserSession.getInstance().getCurrentUser();
        if (user instanceof Instructor) {
            return true;
        }

        JOptionPane.showMessageDialog(null,
                "Access Denied: You are not authorized to manage Section ID: " + sectionId + ".",
                "Authorization Failure",
                JOptionPane.ERROR_MESSAGE);
        return false;
    }


    public boolean isAdmin() {
        return "Admin".equals(UserSession.getInstance().getRole());
    }
}